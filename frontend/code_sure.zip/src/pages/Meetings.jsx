import { useEffect, useState } from 'react';
import { Table, Tag, Button, Card, Typography, Space, Modal, Form, Input, Select, DatePicker, App, Row, Col, Alert } from 'antd';
import { PlusOutlined, StopOutlined } from '@ant-design/icons';
import { useNavigate, useSearchParams } from 'react-router-dom';
import dayjs from 'dayjs';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';

const { Title, Text } = Typography;

const STATUS_COLORS = { DRAFT: 'default', SENT: 'blue', CONFIRMED: 'green', CANCELLED: 'red' };
const STATUS_LABELS = { DRAFT: 'Brouillon', SENT: 'Envoyée', CONFIRMED: 'Confirmée', CANCELLED: 'Annulée' };

export default function Meetings() {
    const navigate = useNavigate();
    const [searchParams, setSearchParams] = useSearchParams();
    const { user } = useAuth();
    const { message, modal } = App.useApp();
    const [meetings, setMeetings] = useState([]);
    const [rooms, setRooms] = useState([]);
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [createModal, setCreateModal] = useState(false);
    const [createModalError, setCreateModalError] = useState('');
    const [createLoading, setCreateLoading] = useState(false);
    const [form] = Form.useForm();
    const [availableRooms, setAvailableRooms] = useState([]);
    const [loadingRooms, setLoadingRooms] = useState(false);
    const [bookedSlots, setBookedSlots] = useState([]);
    const [pendingRoomId, setPendingRoomId] = useState(null);

    const formatConflictError = (err) => {
        const data = err?.response?.data || {};
        const base = data.error || 'Conflit de planning détecté';
        if (!data.userId) return base;
        const u = users.find((x) => x.id === data.userId);
        if (!u) return base;
        return `${base} Utilisateur concerné : ${u.name} (${u.email}).`;
    };

    useEffect(() => { fetchAll(); }, []);

    // Ouvrir la modal depuis /rooms ou /calendar via ?create=1&roomId=...&date=YYYY-MM-DD
    useEffect(() => {
        if (searchParams.get('create') !== '1') return;

        const dateParam = searchParams.get('date');
        const roomIdParam = searchParams.get('roomId');

        let start = dayjs().hour(9).minute(0).second(0);
        let end = dayjs().hour(10).minute(0).second(0);
        if (dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam)) {
            const d = dayjs(dateParam);
            start = d.hour(9).minute(0).second(0);
            end = d.hour(10).minute(0).second(0);
        }

        if (roomIdParam) setPendingRoomId(roomIdParam);
        else setPendingRoomId(null);

        form.setFieldsValue({
            startTime: start,
            endTime: end,
            roomId: undefined,
            meetingLink: '',
            title: '',
            agenda: '',
            participantIds: [],
        });
        setCreateModal(true);
        setSearchParams({}, { replace: true });
    }, [searchParams]);

    // Quand les salles libres arrivent, appliquer roomId en attente (ex. depuis /rooms)
    useEffect(() => {
        if (!createModal || !pendingRoomId || availableRooms.length === 0) return;
        if (availableRooms.some((r) => r.id === pendingRoomId)) {
            form.setFieldValue('roomId', pendingRoomId);
            setPendingRoomId(null);
        }
    }, [createModal, pendingRoomId, availableRooms]);

    // Charger les salles libres pour le créneau choisi (réunions sur salle libre + créneau libre)
    const startTime = Form.useWatch('startTime', form);
    const endTime = Form.useWatch('endTime', form);
    useEffect(() => {
        if (!createModal || !startTime || !endTime) {
            setAvailableRooms([]);
            return;
        }
        const start = startTime.toDate ? startTime.toDate() : new Date(startTime);
        const end = endTime.toDate ? endTime.toDate() : new Date(endTime);
        if (start >= end) {
            setAvailableRooms([]);
            return;
        }
        setLoadingRooms(true);
        api.get('/rooms/available', {
            params: { startTime: start.toISOString(), endTime: end.toISOString() },
        })
            .then((res) => {
                const list = res.data || [];
                setAvailableRooms(list);
                const currentRoomId = form.getFieldValue('roomId');
                if (currentRoomId && !list.some((r) => r.id === currentRoomId)) {
                    form.setFieldValue('roomId', undefined);
                }
            })
            .catch(() => setAvailableRooms([]))
            .finally(() => setLoadingRooms(false));
    }, [createModal, startTime, endTime]);

    const roomId = Form.useWatch('roomId', form);
    useEffect(() => {
        if (!createModal || !roomId || !startTime) {
            setBookedSlots([]);
            return;
        }
        const start = startTime.toDate ? startTime.toDate() : new Date(startTime);
        const dateStr = start.toISOString().split('T')[0];
        api.get(`/rooms/${roomId}/bookings`, { params: { date: dateStr } })
            .then((res) => setBookedSlots(res.data?.bookings || []))
            .catch(() => setBookedSlots([]));
    }, [createModal, roomId, startTime]);

    const fetchAll = async () => {
        try {
            const [meetRes, roomRes, userRes] = await Promise.all([
                api.get('/meetings'),
                api.get('/rooms'),
                api.get('/users/participants'),
            ]);
            setMeetings(meetRes.data);
            setRooms(roomRes.data);
            setUsers(userRes.data || []);
        } catch {
            message.error('Impossible de charger les données');
        } finally {
            setLoading(false);
        }
    };

    const handleCreate = async (values) => {
        const start = values.startTime?.toDate?.() ?? values.startTime;
        const end = values.endTime?.toDate?.() ?? values.endTime;
        const link = String(values.meetingLink || '').trim();
        if (!start || !end || start >= end) {
            message.error('Choisissez un créneau valide (fin après le début)');
            return;
        }
        if (!values.roomId && !link) {
            message.error('Renseignez une salle ou un lien de visioconférence');
            return;
        }
        if (link) {
            try {
                const u = new URL(link);
                if (!['http:', 'https:'].includes(u.protocol)) {
                    throw new Error('invalid');
                }
            } catch {
                message.error('Lien de visioconférence invalide (http/https requis)');
                return;
            }
        }
        if (values.roomId) {
            const isAvailable = availableRooms.some((r) => r.id === values.roomId);
            if (!isAvailable) {
                message.error('Cette salle n\'est plus libre sur le créneau choisi. Sélectionnez une salle proposée.');
                return;
            }
        }
        setCreateLoading(true);
        setCreateModalError('');
        try {
            await api.post('/meetings', {
                title: values.title,
                agenda: values.agenda,
                roomId: values.roomId || undefined,
                meetingLink: link || undefined,
                startTime: (start && start.toISOString) ? start.toISOString() : new Date(start).toISOString(),
                endTime: (end && end.toISOString) ? end.toISOString() : new Date(end).toISOString(),
                participants: values.participantIds || [],
            });
            message.success('Réunion créée');
            setCreateModal(false);
            form.resetFields();
            setAvailableRooms([]);
            setCreateModalError('');
            fetchAll();
        } catch (err) {
            const msg = formatConflictError(err) || 'Erreur lors de la création';
            setCreateModalError(msg);
            message.error(msg);
        } finally {
            setCreateLoading(false);
        }
    };

    const handleCancel = (id) => {
        modal.confirm({
            title: 'Annuler la réunion',
            content: 'Êtes-vous sûr de vouloir annuler cette réunion ? Les participants seront notifiés.',
            okText: 'Annuler la réunion',
            okButtonProps: { danger: true },
            cancelText: 'Retour',
            onOk: async () => {
                try {
                    await api.put(`/meetings/${id}/cancel`);
                    message.success('Réunion annulée');
                    fetchAll();
                } catch (err) {
                    message.error(err.response?.data?.error || 'Erreur');
                }
            },
        });
    };

    const columns = [
        { title: 'Titre', dataIndex: 'title', key: 'title', ellipsis: true },
        {
            title: 'Date',
            dataIndex: 'startTime',
            key: 'startTime',
            render: (d) => new Date(d).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }),
        },
        { title: 'Salle', key: 'room', render: (_, r) => r.room?.name || '—' },
        {
            title: 'Statut',
            dataIndex: 'status',
            key: 'status',
            render: (s) => <Tag color={STATUS_COLORS[s]}>{STATUS_LABELS[s] || s}</Tag>,
        },
        {
            title: 'Actions',
            key: 'actions',
            render: (_, record) => (
                <Space>
                    <Button size="small" type="link" onClick={() => navigate(`/meetings/${record.id}`)}>
                        Détail
                    </Button>
                    {record.status !== 'CANCELLED' && (record.organizerId === user?.id || user?.role === 'ADMIN') && (
                        <Button size="small" danger icon={<StopOutlined />} onClick={() => handleCancel(record.id)}>
                            Annuler
                        </Button>
                    )}
                </Space>
            ),
        },
    ];

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
                <Title level={3} style={{ margin: 0 }}>Réunions</Title>
                <Button type="primary" icon={<PlusOutlined />} onClick={() => setCreateModal(true)}>
                    Nouvelle réunion
                </Button>
            </div>

            <Card>
                <Table
                    columns={columns}
                    dataSource={meetings}
                    rowKey="id"
                    loading={loading}
                    pagination={{ pageSize: 10 }}
                    scroll={{ x: 'max-content' }}
                    locale={{ emptyText: 'Aucune réunion' }}
                />
            </Card>

            <Modal
                title="Nouvelle réunion"
                open={createModal}
                onOk={() => form.submit()}
                onCancel={() => { setCreateModal(false); form.resetFields(); setCreateModalError(''); }}
                okText="Créer"
                confirmLoading={createLoading}
                width={600}
            >
                {createModalError && (
                    <Alert
                        type="error"
                        showIcon
                        title={createModalError}
                        style={{ marginTop: 12, marginBottom: 12 }}
                    />
                )}
                <Form form={form} layout="vertical" onFinish={handleCreate} style={{ marginTop: 16 }}>
                    <Form.Item name="title" label="Titre" rules={[{ required: true, message: 'Titre requis' }]}>
                        <Input />
                    </Form.Item>
                    <Form.Item name="agenda" label="Ordre du jour">
                        <Input.TextArea rows={3} />
                    </Form.Item>
                    <Row gutter={16}>
                        <Col span={12}>
                            <Form.Item name="startTime" label="Début" rules={[{ required: true, message: 'Requis' }]}>
                                <DatePicker showTime style={{ width: '100%' }} format="DD/MM/YYYY HH:mm" />
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item name="endTime" label="Fin" rules={[{ required: true, message: 'Requis' }]}>
                                <DatePicker showTime style={{ width: '100%' }} format="DD/MM/YYYY HH:mm" />
                            </Form.Item>
                        </Col>
                    </Row>
                    <Form.Item
                        name="roomId"
                        label="Salle (libre sur le créneau choisi)"
                        extra={startTime && endTime ? (
                            <Text type="secondary">
                                Seules les salles libres sur le créneau sélectionné sont proposées.
                            </Text>
                        ) : (
                            <Text type="secondary">Choisissez d'abord le créneau (début et fin) pour voir les salles disponibles.</Text>
                        )}
                    >
                        <Select
                            placeholder={startTime && endTime ? "Sélectionner une salle libre" : "Choisir d'abord le créneau"}
                            allowClear
                            loading={loadingRooms}
                            disabled={!startTime || !endTime}
                            optionFilterProp="label"
                        >
                            {availableRooms.map((r) => (
                                <Select.Option key={r.id} value={r.id} label={`${r.name} (${r.capacity} pers.)`}>
                                    {r.name} — {r.capacity} pers. {r.location ? `· ${r.location}` : ''}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>
                    <Form.Item
                        name="meetingLink"
                        label="Lien visio (optionnel)"
                        extra={<Text type="secondary">Google Meet, Zoom, Teams, Jitsi... (http/https)</Text>}
                    >
                        <Input placeholder="https://meet.google.com/..." />
                    </Form.Item>
                    {bookedSlots.length > 0 && (
                        <Alert
                            type="info"
                            showIcon
                            title="Créneaux déjà réservés pour cette salle ce jour"
                            description={
                                <ul style={{ margin: 0, paddingLeft: 20 }}>
                                    {bookedSlots.map((b) => (
                                        <li key={b.id}>
                                            <Text strong>{b.startTime} – {b.endTime}</Text>
                                            {b.meetingTitle && ` — ${b.meetingTitle}`}
                                        </li>
                                    ))}
                                </ul>
                            }
                            style={{ marginBottom: 16 }}
                        />
                    )}
                    {roomId && startTime && endTime && availableRooms.length > 0 && !availableRooms.some((r) => r.id === roomId) && (
                        <Alert
                            type="warning"
                            showIcon
                            title="Cette salle n'est pas disponible sur le créneau choisi"
                            description="Le créneau sélectionné est déjà réservé pour cette salle. Choisissez une autre salle dans la liste ou un autre horaire."
                            style={{ marginBottom: 16 }}
                        />
                    )}
                    {users.length > 0 && (
                        <Form.Item name="participantIds" label="Participants supplémentaires">
                            <Select mode="multiple" placeholder="Sélectionner des participants" optionFilterProp="children">
                                {users.filter(u => u.id !== user?.id).map(u => (
                                    <Select.Option key={u.id} value={u.id}>{u.name} — {u.email}</Select.Option>
                                ))}
                            </Select>
                        </Form.Item>
                    )}
                </Form>
            </Modal>
        </div>
    );
}
