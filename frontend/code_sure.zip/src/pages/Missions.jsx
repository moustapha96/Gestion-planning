import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
    Card,
    Table,
    Button,
    Space,
    Typography,
    App,
    Tag,
    Popconfirm,
} from 'antd';
import { PlusOutlined, FlagOutlined, EnvironmentOutlined, EditOutlined, DeleteOutlined, EyeOutlined } from '@ant-design/icons';
import dayjs from 'dayjs';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';

const { Title } = Typography;

const STATUS_LABELS = { CONFIRMED: 'Confirmée', CANCELLED: 'Annulée' };
const STATUS_COLORS = { CONFIRMED: 'green', CANCELLED: 'default' };

export default function Missions() {
    const navigate = useNavigate();
    const { user } = useAuth();
    const { message } = App.useApp();
    const [missions, setMissions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [actionLoadingId, setActionLoadingId] = useState(null);

    const fetchMissions = async () => {
        try {
            const res = await api.get('/missions');
            setMissions(res.data || []);
        } catch {
            message.error('Impossible de charger les missions');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchMissions();
    }, []);

    const isAdmin = user?.role === 'ADMIN';
    const canManageMission = (record) =>
        isAdmin || record.createdById === user?.id;

    const handleCancelMission = async (missionId) => {
        setActionLoadingId(missionId);
        try {
            await api.delete(`/missions/${missionId}`);
            message.success('Mission annulée');
            fetchMissions();
        } catch (err) {
            message.error(err.response?.data?.error || 'Erreur');
        } finally {
            setActionLoadingId(null);
        }
    };

    const columns = [
        {
            title: 'Mission',
            dataIndex: 'title',
            key: 'title',
            render: (title, record) => (
                <Space>
                    <FlagOutlined style={{ color: '#722ed1' }} />
                    <Button type="link" onClick={() => navigate(`/missions/${record.id}`)} style={{ padding: 0 }}>
                        {title}
                    </Button>
                </Space>
            ),
        },
        {
            title: 'Lieu',
            dataIndex: 'location',
            key: 'location',
            ellipsis: true,
            render: (loc) => (
                <span>
                    <EnvironmentOutlined style={{ marginRight: 4 }} />
                    {loc}
                </span>
            ),
        },
        {
            title: 'Début',
            dataIndex: 'startTime',
            key: 'startTime',
            render: (t) => (t ? dayjs(t).format('DD/MM/YYYY HH:mm') : '—'),
        },
        {
            title: 'Fin',
            dataIndex: 'endTime',
            key: 'endTime',
            render: (t) => (t ? dayjs(t).format('DD/MM/YYYY HH:mm') : '—'),
        },
        {
            title: 'Créée par',
            key: 'createdBy',
            render: (_, r) => r.createdBy?.name || '—',
        },
        // {
        //     title: 'Intervenants',
        //     key: 'assignments',
        //     render: (_, r) =>
        //         r.assignments?.length
        //             ? r.assignments.map((a) => a.user?.name).filter(Boolean).join(', ') || '—'
        //             : '—',
        // },
        ...(isAdmin
            ? [{
                title: 'Statut',
                dataIndex: 'status',
                key: 'status',
                render: (s) => <Tag color={STATUS_COLORS[s]}>{STATUS_LABELS[s] || s}</Tag>,
            }]
            : []),
        {
            title: 'Actions',
            key: 'actions',
            width: 220,
            render: (_, record) => (
                <Space size="small">
                    <Button
                        type="link"
                        size="small"
                        icon={<EyeOutlined />}
                        onClick={() => navigate(`/missions/${record.id}`)}
                    >
                        Détail
                    </Button>
                    {canManageMission(record) && (
                        <>
                            <Button
                                type="link"
                                size="small"
                                icon={<EditOutlined />}
                                onClick={() => navigate(`/missions/${record.id}/edit`)}
                            >
                                Modifier
                            </Button>
                            <Popconfirm
                                title="Annuler cette mission ?"
                                description="La mission sera marquée comme annulée."
                                onConfirm={() => handleCancelMission(record.id)}
                                okText="Oui, annuler"
                                cancelText="Non"
                                okButtonProps={{ danger: true, loading: actionLoadingId === record.id }}
                            >
                                <Button
                                    type="link"
                                    size="small"
                                    danger
                                    icon={<DeleteOutlined />}
                                    loading={actionLoadingId === record.id}
                                >
                                    Annuler
                                </Button>
                            </Popconfirm>
                        </>
                    )}
                </Space>
            ),
        },
    ];

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
                <Title level={3} style={{ margin: 0 }}>
                    <FlagOutlined /> Missions
                </Title>
                <Button type="primary" icon={<PlusOutlined />} onClick={() => navigate('/missions/new')}>
                    Nouvelle mission
                </Button>
            </div>

            <Card>
                <Table
                    rowKey="id"
                    loading={loading}
                    dataSource={missions}
                    columns={columns}
                    pagination={{ pageSize: 10 }}
                    scroll={{ x: 'max-content' }}
                    locale={{ emptyText: 'Aucune mission' }}
                />
            </Card>
        </div>
    );
}
