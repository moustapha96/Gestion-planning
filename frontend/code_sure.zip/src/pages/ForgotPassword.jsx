import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Form, Input, Button, Typography, Alert, Result } from 'antd';
import { MailOutlined, ArrowLeftOutlined } from '@ant-design/icons';
import api from '../api/client';

const { Title, Text } = Typography;

export default function ForgotPassword() {
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (values) => {
        setError('');
        setLoading(true);
        try {
            await api.post('/auth/forgot-password', { email: values.email });
            setSuccess(true);
        } catch {
            setError('Une erreur est survenue. Veuillez réessayer.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div
            className="auth-page"
            style={{
                minHeight: '100vh',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                background: 'linear-gradient(135deg, #1F5C8B 0%, #0d3a5a 100%)',
            }}
        >
            <div style={{ width: '100%', maxWidth: 420 }}>
                {success ? (
                    <Result
                        status="success"
                        title="Email envoyé"
                        subTitle="Si cet email est enregistré, vous recevrez un lien de réinitialisation dans quelques instants."
                        extra={
                            <Link to="/login">
                                <Button type="primary">Retour à la connexion</Button>
                            </Link>
                        }
                    />
                ) : (
                    <>
                        <Link to="/login" style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'rgba(255,255,255,0.9)', marginBottom: 24, width: 'fit-content' }}>
                            <ArrowLeftOutlined /> Retour
                        </Link>
                        <Title level={3} style={{ marginBottom: 4, color: 'white' }}>Mot de passe oublié</Title>
                        <Text style={{ display: 'block', marginBottom: 24, color: 'rgba(255,255,255,0.85)' }}>
                            Saisissez votre email pour recevoir un lien de réinitialisation.
                        </Text>

                        {error && <Alert title={error} type="error" showIcon style={{ marginBottom: 16 }} />}

                        <Form layout="vertical" onFinish={handleSubmit}>
                            <Form.Item name="email" label={<span style={{ color: 'rgba(255,255,255,0.9)' }}>Email</span>} rules={[{ required: true, type: 'email', message: 'Email valide requis' }]}>
                                <Input prefix={<MailOutlined />} size="large" placeholder="votre@email.com" />
                            </Form.Item>
                            <Form.Item>
                                <Button type="primary" htmlType="submit" size="large" loading={loading} block>
                                    Envoyer le lien
                                </Button>
                            </Form.Item>
                        </Form>
                    </>
                )}
            </div>
        </div>
    );
}
