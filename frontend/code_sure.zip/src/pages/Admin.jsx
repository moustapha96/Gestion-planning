import { useEffect, useState, useMemo } from 'react';
import {
    Table, Tag, Button, Card, Typography, Space, Modal, Form, Input, Select,
    Tabs, Popconfirm, App, Tooltip, Row, Col, List, Spin, TimePicker, Switch,
} from 'antd';
import {
    PlusOutlined, StopOutlined, CheckOutlined, KeyOutlined, EditOutlined,
    MailOutlined, CalendarOutlined, UserOutlined, FileTextOutlined,
    BankOutlined, DeleteOutlined, SearchOutlined,
    BarChartOutlined, BellOutlined, SafetyCertificateOutlined, SettingOutlined,
} from '@ant-design/icons';
import dayjs from 'dayjs';
import AdminPlanningsTab from './AdminPlanningsTab';
import AdminStatsTab from './AdminStatsTab';
import AdminAuditTab from './AdminAuditTab';
import AdminNotifTab from './AdminNotifTab';
import api from '../api/client';
import { useAuth } from '../context/AuthContext';

const { Title, Text } = Typography;
const ROLE_COLORS = { RESPONSABLE: 'blue', CONSOLIDATEUR: 'purple', DG: 'gold', ADMIN: 'red' };
const ROLE_LABELS = { RESPONSABLE: 'Responsable', CONSOLIDATEUR: 'Consolidateur', DG: 'Dir. Général', ADMIN: 'Administrateur' };

// ════════════════════════════════════════════════════════════════════
// ONGLET UTILISATEURS
// ════════════════════════════════════════════════════════════════════
function UsersTab() {
    const { user: currentUser } = useAuth();
    const { message } = App.useApp();
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    const [roleFilter, setRoleFilter] = useState(undefined);
    const [statusFilter, setStatusFilter] = useState(undefined);
    const [createModal, setCreateModal] = useState(false);
    const [editModal, setEditModal] = useState({ open: false, user: null });
    const [resetModal, setResetModal] = useState({ open: false, userId: null, userName: '' });
    const [deleteId, setDeleteId] = useState(null);
    const [sendingLink, setSendingLink] = useState(null);
    const [createLoading, setCreateLoading] = useState(false);
    const [editLoading, setEditLoading] = useState(false);
    const [resetLoading, setResetLoading] = useState(false);
    const [toggleLoadingId, setToggleLoadingId] = useState(null);
    const [form] = Form.useForm();
    const [editForm] = Form.useForm();
    const [resetForm] = Form.useForm();

    const fetchUsers = async () => {
        try {
            const res = await api.get('/users');
            setUsers(res.data);
        } catch {
            message.error('Impossible de charger les utilisateurs');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { fetchUsers(); }, []);

    const filtered = useMemo(() => {
        return users.filter((u) => {
            const q = search.toLowerCase();
            if (q && !u.name.toLowerCase().includes(q) && !u.email.toLowerCase().includes(q)) return false;
            if (roleFilter && u.role !== roleFilter) return false;
            if (statusFilter === 'active' && !u.isActive) return false;
            if (statusFilter === 'inactive' && u.isActive) return false;
            return true;
        });
    }, [users, search, roleFilter, statusFilter]);

    const handleCreate = async (values) => {
        setCreateLoading(true);
        try {
            await api.post('/users', values);
            message.success('Utilisateur créé — email d\'activation envoyé');
            setCreateModal(false);
            form.resetFields();
            fetchUsers();
        } catch (err) {
            message.error(err.response?.data?.error || 'Erreur lors de la création');
        } finally {
            setCreateLoading(false);
        }
    };

    const handleToggleActive = async (userId, isActive) => {
        setToggleLoadingId(userId);
        try {
            await api.put(`/users/${userId}/${isActive ? 'deactivate' : 'activate'}`);
            message.success(isActive ? 'Utilisateur désactivé' : 'Utilisateur réactivé');
            fetchUsers();
        } catch (err) {
            message.error(err.response?.data?.error || 'Erreur');
        } finally {
            setToggleLoadingId(null);
        }
    };

    const handleResetPassword = async (values) => {
        setResetLoading(true);
        try {
            await api.put(`/users/${resetModal.userId}/reset-password`, { newPassword: values.newPassword });
            message.success('Mot de passe réinitialisé — envoyé par email');
            setResetModal({ open: false, userId: null, userName: '' });
            resetForm.resetFields();
        } catch (err) {
            message.error(err.response?.data?.error || 'Erreur');
        } finally {
            setResetLoading(false);
        }
    };

    const openEdit = (record) => {
        setEditModal({ open: true, user: record });
        editForm.setFieldsValue({ name: record.name, email: record.email, role: record.role });
    };

    const handleEditSubmit = async () => {
        if (!editModal.user) return;
        setEditLoading(true);
        try {
            const values = await editForm.validateFields();
            await api.put(`/users/${editModal.user.id}`, { name: values.name, email: values.email, role: values.role });
            message.success('Utilisateur modifié');
            setEditModal({ open: false, user: null });
            editForm.resetFields();
            fetchUsers();
        } catch (err) {
            if (err.errorFields) return;
            message.error(err.response?.data?.error || 'Erreur');
        } finally {
            setEditLoading(false);
        }
    };

    const handleSendResetLink = async (userId, userName) => {
        setSendingLink(userId);
        try {
            await api.post(`/users/${userId}/send-reset-link`);
            message.success(`Lien de réinitialisation envoyé à ${userName}`);
        } catch (err) {
            message.error(err.response?.data?.error || 'Erreur');
        } finally {
            setSendingLink(null);
        }
    };

    const handleDelete = async (userId, email) => {
        setDeleteId(userId);
        try {
            await api.delete(`/users/${userId}`);
            message.success(`Utilisateur ${email} supprimé (soft-delete)`);
            fetchUsers();
        } catch (err) {
            message.error(err.response?.data?.error || 'Erreur');
        } finally {
            setDeleteId(null);
        }
    };

    const columns = [
        {
            title: 'Nom',
            dataIndex: 'name',
            key: 'name',
            render: (name, r) => (
                <div>
                    <Text strong>{name}</Text>
                    <br />
                    <Text type="secondary" style={{ fontSize: 11 }}>
                        Créé le {new Date(r.createdAt).toLocaleDateString('fr-FR')}
                    </Text>
                </div>
            ),
        },
        { title: 'Email', dataIndex: 'email', key: 'email', ellipsis: true },
        {
            title: 'Rôle',
            dataIndex: 'role',
            key: 'role',
            render: (role) => <Tag color={ROLE_COLORS[role]}>{ROLE_LABELS[role] || role}</Tag>,
        },
        {
            title: 'Statut',
            dataIndex: 'isActive',
            key: 'isActive',
            width: 90,
            render: (isActive) => <Tag color={isActive ? 'green' : 'red'}>{isActive ? 'Actif' : 'Inactif'}</Tag>,
        },
        {
            title: 'Actions',
            key: 'actions',
            width: 290,
            render: (_, record) => (
                <Space wrap size={[4, 4]}>
                    <Tooltip title="Modifier (nom, email, rôle)">
                        <Button size="small" icon={<EditOutlined />} onClick={() => openEdit(record)} />
                    </Tooltip>
                    <Tooltip title="Définir un nouveau mot de passe">
                        <Button
                            size="small"
                            icon={<KeyOutlined />}
                            onClick={() => setResetModal({ open: true, userId: record.id, userName: record.name })}
                        />
                    </Tooltip>
                    <Popconfirm
                        title={`Envoyer un lien à ${record.name} ?`}
                        description="Lien valide 1h — l'utilisateur choisit son nouveau mot de passe."
                        onConfirm={() => handleSendResetLink(record.id, record.name)}
                        okText="Envoyer"
                        cancelText="Annuler"
                    >
                        <Tooltip title="Envoyer lien réinitialisation">
                            <Button size="small" icon={<MailOutlined />} loading={sendingLink === record.id} />
                        </Tooltip>
                    </Popconfirm>
                    {record.id !== currentUser?.id && (
                        <Popconfirm
                            title={record.isActive ? 'Désactiver cet utilisateur ?' : 'Réactiver cet utilisateur ?'}
                            onConfirm={() => handleToggleActive(record.id, record.isActive)}
                            okText="Confirmer"
                            cancelText="Annuler"
                            okButtonProps={{ loading: toggleLoadingId === record.id }}
                        >
                            <Button
                                size="small"
                                danger={record.isActive}
                                type={record.isActive ? 'default' : 'primary'}
                                icon={record.isActive ? <StopOutlined /> : <CheckOutlined />}
                                loading={toggleLoadingId === record.id}
                            >
                                {record.isActive ? 'Désactiver' : 'Réactiver'}
                            </Button>
                        </Popconfirm>
                    )}
                    {record.id !== currentUser?.id && (
                        <Popconfirm
                            title="Supprimer cet utilisateur ?"
                            description="Soft-delete : les données liées sont préservées (CDC §3.9.1)."
                            onConfirm={() => handleDelete(record.id, record.email)}
                            okText="Supprimer"
                            cancelText="Annuler"
                            okButtonProps={{ danger: true, loading: deleteId === record.id }}
                        >
                            <Tooltip title="Supprimer (soft-delete)">
                                <Button size="small" danger type="text" icon={<DeleteOutlined />} loading={deleteId === record.id} />
                            </Tooltip>
                        </Popconfirm>
                    )}
                </Space>
            ),
        },
    ];

    return (
        <>
            <Row gutter={[12, 12]} style={{ marginBottom: 16 }}>
                <Col xs={24} sm={8} md={7}>
                    <Input
                        prefix={<SearchOutlined />}
                        placeholder="Rechercher nom ou email…"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        allowClear
                    />
                </Col>
                <Col xs={12} sm={5} md={4}>
                    <Select
                        allowClear
                        placeholder="Rôle"
                        style={{ width: '100%' }}
                        value={roleFilter}
                        onChange={setRoleFilter}
                        options={Object.entries(ROLE_LABELS).map(([v, l]) => ({ value: v, label: l }))}
                    />
                </Col>
                <Col xs={12} sm={5} md={4}>
                    <Select
                        allowClear
                        placeholder="Statut"
                        style={{ width: '100%' }}
                        value={statusFilter}
                        onChange={setStatusFilter}
                        options={[{ value: 'active', label: 'Actif' }, { value: 'inactive', label: 'Inactif' }]}
                    />
                </Col>
                <Col xs={24} sm={6} md={9} style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, alignItems: 'center' }}>
                    <Text type="secondary" style={{ fontSize: 12 }}>{filtered.length} résultat(s)</Text>
                    <Button type="primary" icon={<PlusOutlined />} onClick={() => setCreateModal(true)}>
                        Nouvel utilisateur
                    </Button>
                </Col>
            </Row>

            <Table
                columns={columns}
                dataSource={filtered}
                rowKey="id"
                loading={loading}
                pagination={{ pageSize: 10, showTotal: (t) => `${t} utilisateur(s)` }}
                scroll={{ x: 'max-content' }}
                size="small"
            />

            {/* Modal création */}
            <Modal
                title="Créer un utilisateur"
                open={createModal}
                onOk={() => form.submit()}
                onCancel={() => { setCreateModal(false); form.resetFields(); }}
                okText="Créer"
                confirmLoading={createLoading}
                destroyOnClose
            >
                <Form form={form} layout="vertical" onFinish={handleCreate} style={{ marginTop: 16 }}>
                    <Row gutter={16}>
                        <Col span={14}>
                            <Form.Item name="name" label="Nom complet" rules={[{ required: true }]}>
                                <Input />
                            </Form.Item>
                        </Col>
                        <Col span={10}>
                            <Form.Item name="role" label="Rôle" initialValue="RESPONSABLE" rules={[{ required: true }]}>
                                <Select options={Object.entries(ROLE_LABELS).map(([v, l]) => ({ value: v, label: l }))} />
                            </Form.Item>
                        </Col>
                    </Row>
                    <Form.Item name="email" label="Email" rules={[{ required: true, type: 'email' }]}>
                        <Input />
                    </Form.Item>
                    <Form.Item
                        name="password"
                        label="Mot de passe initial"
                        rules={[
                            { required: true, min: 8 },
                            {
                                pattern: /^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9])/,
                                message: 'Doit contenir 1 majuscule, 1 chiffre, 1 caractère spécial (CDC §3.1.2)',
                            },
                        ]}
                    >
                        <Input.Password />
                    </Form.Item>
                </Form>
            </Modal>

            {/* Modal modification */}
            <Modal
                title="Modifier l'utilisateur"
                open={editModal.open}
                onOk={handleEditSubmit}
                onCancel={() => { setEditModal({ open: false, user: null }); editForm.resetFields(); }}
                okText="Enregistrer"
                confirmLoading={editLoading}
                destroyOnClose
            >
                <Form form={editForm} layout="vertical" style={{ marginTop: 16 }}>
                    <Form.Item name="name" label="Nom complet" rules={[{ required: true }]}>
                        <Input />
                    </Form.Item>
                    <Form.Item name="email" label="Email" rules={[{ required: true, type: 'email' }]}>
                        <Input />
                    </Form.Item>
                    <Form.Item name="role" label="Rôle" rules={[{ required: true }]}>
                        <Select options={Object.entries(ROLE_LABELS).map(([v, l]) => ({ value: v, label: l }))} />
                    </Form.Item>
                </Form>
            </Modal>

            {/* Modal réinitialisation */}
            <Modal
                title={`Réinitialiser le mot de passe — ${resetModal.userName}`}
                open={resetModal.open}
                onOk={() => resetForm.submit()}
                onCancel={() => { setResetModal({ open: false, userId: null, userName: '' }); resetForm.resetFields(); }}
                okText="Réinitialiser"
                confirmLoading={resetLoading}
                destroyOnClose
            >
                <Form form={resetForm} layout="vertical" onFinish={handleResetPassword} style={{ marginTop: 16 }}>
                    <Form.Item
                        name="newPassword"
                        label="Nouveau mot de passe"
                        rules={[
                            { required: true, min: 8 },
                            { pattern: /^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9])/, message: '1 majuscule, 1 chiffre, 1 spécial requis' },
                        ]}
                    >
                        <Input.Password />
                    </Form.Item>
                    <Form.Item
                        name="confirm"
                        label="Confirmer le mot de passe"
                        dependencies={['newPassword']}
                        rules={[
                            { required: true },
                            ({ getFieldValue }) => ({
                                validator(_, value) {
                                    if (!value || getFieldValue('newPassword') === value) return Promise.resolve();
                                    return Promise.reject('Les mots de passe ne correspondent pas');
                                },
                            }),
                        ]}
                    >
                        <Input.Password />
                    </Form.Item>
                </Form>
            </Modal>
        </>
    );
}

// ════════════════════════════════════════════════════════════════════
// ONGLET SALLES
// ════════════════════════════════════════════════════════════════════
function RoomsTab() {
    const { message } = App.useApp();
    const [rooms, setRooms] = useState([]);
    const [loading, setLoading] = useState(true);
    const [createModal, setCreateModal] = useState(false);
    const [editModal, setEditModal] = useState({ open: false, room: null });
    const [createLoading, setCreateLoading] = useState(false);
    const [editLoading, setEditLoading] = useState(false);
    const [toggleId, setToggleId] = useState(null);
    const [form] = Form.useForm();
    const [editForm] = Form.useForm();

    const fetchRooms = async () => {
        try {
            const res = await api.get('/rooms', { params: { all: '1' } });
            setRooms(res.data);
        } catch {
            message.error('Impossible de charger les salles');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { fetchRooms(); }, []);

    const parseEquipment = (eq) => {
        if (!eq) return [];
        if (Array.isArray(eq)) return eq;
        try { return JSON.parse(eq); } catch { return eq.split(',').map(s => s.trim()).filter(Boolean); }
    };

    const handleCreate = async (values) => {
        setCreateLoading(true);
        try {
            const equipment = values.equipment
                ? values.equipment.split(',').map(s => s.trim()).filter(Boolean)
                : [];
            await api.post('/rooms', {
                ...values,
                capacity: parseInt(values.capacity),
                equipment,
                openFrom: values.openFrom ? dayjs(values.openFrom).format('HH:mm') : '08:00',
                openTo: values.openTo ? dayjs(values.openTo).format('HH:mm') : '19:00',
            });
            message.success('Salle créée');
            setCreateModal(false);
            form.resetFields();
            fetchRooms();
        } catch (err) {
            message.error(err.response?.data?.error || 'Erreur');
        } finally {
            setCreateLoading(false);
        }
    };

    const openEdit = (room) => {
        setEditModal({ open: true, room });
        const eq = parseEquipment(room.equipment);
        editForm.setFieldsValue({
            name: room.name,
            capacity: room.capacity,
            location: room.location,
            equipment: eq.join(', '),
            openFrom: room.openFrom ? dayjs(room.openFrom, 'HH:mm') : dayjs('08:00', 'HH:mm'),
            openTo: room.openTo ? dayjs(room.openTo, 'HH:mm') : dayjs('19:00', 'HH:mm'),
        });
    };

    const handleEditSubmit = async () => {
        if (!editModal.room) return;
        setEditLoading(true);
        try {
            const values = await editForm.validateFields();
            const equipment = values.equipment
                ? values.equipment.split(',').map(s => s.trim()).filter(Boolean)
                : [];
            await api.put(`/rooms/${editModal.room.id}`, {
                name: values.name,
                capacity: parseInt(values.capacity),
                location: values.location,
                equipment,
                openFrom: values.openFrom ? dayjs(values.openFrom).format('HH:mm') : undefined,
                openTo: values.openTo ? dayjs(values.openTo).format('HH:mm') : undefined,
            });
            message.success('Salle modifiée');
            setEditModal({ open: false, room: null });
            editForm.resetFields();
            fetchRooms();
        } catch (err) {
            if (err.errorFields) return;
            message.error(err.response?.data?.error || 'Erreur');
        } finally {
            setEditLoading(false);
        }
    };

    const handleToggle = async (room) => {
        setToggleId(room.id);
        try {
            if (room.status === 'ACTIVE') {
                await api.delete(`/rooms/${room.id}`);
                message.success('Salle désactivée');
            } else {
                await api.put(`/rooms/${room.id}/activate`);
                message.success('Salle réactivée');
            }
            fetchRooms();
        } catch (err) {
            message.error(err.response?.data?.error || 'Erreur');
        } finally {
            setToggleId(null);
        }
    };

    const RoomFormFields = ({ f }) => (
        <Form form={f} layout="vertical" style={{ marginTop: 16 }}>
            <Row gutter={16}>
                <Col span={14}>
                    <Form.Item name="name" label="Nom de la salle" rules={[{ required: true }]}>
                        <Input />
                    </Form.Item>
                </Col>
                <Col span={10}>
                    <Form.Item name="capacity" label="Capacité (pers.)" rules={[{ required: true }]}>
                        <Input type="number" min={1} />
                    </Form.Item>
                </Col>
            </Row>
            <Form.Item name="location" label="Localisation">
                <Input placeholder="Bâtiment A, 2ème étage, salle 201" />
            </Form.Item>
            <Row gutter={16}>
                <Col span={12}>
                    <Form.Item name="openFrom" label="Ouverture">
                        <TimePicker format="HH:mm" style={{ width: '100%' }} minuteStep={15} />
                    </Form.Item>
                </Col>
                <Col span={12}>
                    <Form.Item name="openTo" label="Fermeture">
                        <TimePicker format="HH:mm" style={{ width: '100%' }} minuteStep={15} />
                    </Form.Item>
                </Col>
            </Row>
            <Form.Item name="equipment" label="Équipements (séparés par virgule)">
                <Input placeholder="Projecteur, Tableau blanc, Visioconférence" />
            </Form.Item>
        </Form>
    );

    const columns = [
        {
            title: 'Salle',
            key: 'name',
            render: (_, r) => (
                <div>
                    <Text strong>{r.name}</Text>
                    <br />
                    <Text type="secondary" style={{ fontSize: 11 }}>{r.location || '—'}</Text>
                </div>
            ),
        },
        { title: 'Capacité', dataIndex: 'capacity', key: 'capacity', width: 90, render: (c) => `${c} pers.` },
        {
            title: 'Horaires',
            key: 'hours',
            width: 120,
            render: (_, r) => <Text type="secondary" style={{ fontSize: 12 }}>{r.openFrom || '08:00'} – {r.openTo || '19:00'}</Text>,
        },
        {
            title: 'Équipements',
            key: 'equipment',
            ellipsis: true,
            render: (_, r) => {
                const eq = parseEquipment(r.equipment);
                return eq.length > 0
                    ? eq.slice(0, 3).map((e) => <Tag key={e} style={{ marginBottom: 2, fontSize: 11 }}>{e}</Tag>)
                    : <Text type="secondary">—</Text>;
            },
        },
        {
            title: 'Statut',
            dataIndex: 'status',
            key: 'status',
            width: 100,
            render: (s) => <Tag color={s === 'ACTIVE' ? 'green' : 'red'}>{s === 'ACTIVE' ? 'Active' : 'Désactivée'}</Tag>,
        },
        {
            title: 'Actions',
            key: 'actions',
            width: 170,
            render: (_, record) => (
                <Space>
                    <Tooltip title="Modifier">
                        <Button size="small" icon={<EditOutlined />} onClick={() => openEdit(record)} />
                    </Tooltip>
                    <Popconfirm
                        title={record.status === 'ACTIVE' ? 'Désactiver cette salle ?' : 'Réactiver cette salle ?'}
                        description={record.status === 'ACTIVE' ? 'Aucune nouvelle réservation ne sera possible.' : undefined}
                        onConfirm={() => handleToggle(record)}
                        okText="Confirmer"
                        cancelText="Annuler"
                        okButtonProps={{ loading: toggleId === record.id }}
                    >
                        <Button
                            size="small"
                            danger={record.status === 'ACTIVE'}
                            type={record.status !== 'ACTIVE' ? 'primary' : 'default'}
                            icon={record.status === 'ACTIVE' ? <StopOutlined /> : <CheckOutlined />}
                            loading={toggleId === record.id}
                        >
                            {record.status === 'ACTIVE' ? 'Désactiver' : 'Activer'}
                        </Button>
                    </Popconfirm>
                </Space>
            ),
        },
    ];

    return (
        <>
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
                <Button type="primary" icon={<PlusOutlined />} onClick={() => setCreateModal(true)}>
                    Nouvelle salle
                </Button>
            </div>

            <Table
                columns={columns}
                dataSource={rooms}
                rowKey="id"
                loading={loading}
                pagination={{ pageSize: 10 }}
                scroll={{ x: 'max-content' }}
                size="small"
            />

            {/* Modal création */}
            <Modal
                title="Créer une salle"
                open={createModal}
                onOk={() => form.submit()}
                onCancel={() => { setCreateModal(false); form.resetFields(); }}
                okText="Créer"
                confirmLoading={createLoading}
                destroyOnClose
                afterOpenChange={(open) => {
                    if (open) {
                        form.setFieldsValue({
                            openFrom: dayjs('08:00', 'HH:mm'),
                            openTo: dayjs('19:00', 'HH:mm'),
                        });
                    }
                }}
            >
                <Form form={form} layout="vertical" onFinish={handleCreate} style={{ marginTop: 16 }}>
                    <Row gutter={16}>
                        <Col span={14}>
                            <Form.Item name="name" label="Nom de la salle" rules={[{ required: true }]}>
                                <Input />
                            </Form.Item>
                        </Col>
                        <Col span={10}>
                            <Form.Item name="capacity" label="Capacité (pers.)" rules={[{ required: true }]}>
                                <Input type="number" min={1} />
                            </Form.Item>
                        </Col>
                    </Row>
                    <Form.Item name="location" label="Localisation">
                        <Input placeholder="Bâtiment A, 2ème étage, salle 201" />
                    </Form.Item>
                    <Row gutter={16}>
                        <Col span={12}>
                            <Form.Item name="openFrom" label="Ouverture">
                                <TimePicker format="HH:mm" style={{ width: '100%' }} minuteStep={15} />
                            </Form.Item>
                        </Col>
                        <Col span={12}>
                            <Form.Item name="openTo" label="Fermeture">
                                <TimePicker format="HH:mm" style={{ width: '100%' }} minuteStep={15} />
                            </Form.Item>
                        </Col>
                    </Row>
                    <Form.Item name="equipment" label="Équipements (séparés par virgule)">
                        <Input placeholder="Projecteur, Tableau blanc, Visioconférence" />
                    </Form.Item>
                </Form>
            </Modal>

            {/* Modal édition */}
            <Modal
                title={`Modifier — ${editModal.room?.name || ''}`}
                open={editModal.open}
                onOk={handleEditSubmit}
                onCancel={() => { setEditModal({ open: false, room: null }); editForm.resetFields(); }}
                okText="Enregistrer"
                confirmLoading={editLoading}
                destroyOnClose
            >
                <RoomFormFields f={editForm} />
            </Modal>
        </>
    );
}

// ════════════════════════════════════════════════════════════════════
// ONGLET RÔLES & PERMISSIONS
// ════════════════════════════════════════════════════════════════════
function RolesPermissionsTab() {
    const [data, setData] = useState({ roles: {}, labels: {} });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        api.get('/users/role-permissions')
            .then((res) => setData({ roles: res.data?.roles || {}, labels: res.data?.labels || {} }))
            .catch(() => setData({ roles: {}, labels: {} }))
            .finally(() => setLoading(false));
    }, []);

    const roleOrder = ['RESPONSABLE', 'CONSOLIDATEUR', 'DG', 'ADMIN'];

    if (loading) return <div style={{ textAlign: 'center', padding: 24 }}><Spin /></div>;

    return (
        <div>
            <Text type="secondary" style={{ display: 'block', marginBottom: 16 }}>
                Droits et capacités associés à chaque rôle dans l&apos;application (lecture seule).
            </Text>
            <Row gutter={[16, 16]}>
                {roleOrder.map((roleKey) => (
                    <Col xs={24} md={12} key={roleKey}>
                        <Card size="small" title={<Tag color={ROLE_COLORS[roleKey]}>{data.labels[roleKey] || ROLE_LABELS[roleKey] || roleKey}</Tag>}>
                            <List
                                size="small"
                                dataSource={data.roles[roleKey] || []}
                                renderItem={(item) => (
                                    <List.Item style={{ padding: '4px 0', border: 'none' }}>
                                        <Text style={{ fontSize: 13 }}>• {item}</Text>
                                    </List.Item>
                                )}
                                locale={{ emptyText: 'Aucune permission définie' }}
                            />
                        </Card>
                    </Col>
                ))}
            </Row>
        </div>
    );
}

function SecurityTab() {
    const { message } = App.useApp();
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [enabled, setEnabled] = useState(false);

    const load = async () => {
        setLoading(true);
        try {
            const { data } = await api.get('/admin/settings');
            setEnabled(String(data?.['2fa_enabled']) === 'true');
        } catch {
            message.error('Impossible de charger les paramètres de sécurité');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        load();
    }, []);

    const toggle2FA = async (checked) => {
        setSaving(true);
        try {
            await api.put('/admin/settings', { '2fa_enabled': checked ? 'true' : 'false' });
            setEnabled(checked);
            message.success(`2FA globale ${checked ? 'activée' : 'désactivée'}`);
        } catch (err) {
            message.error(err.response?.data?.error || 'Erreur mise à jour');
        } finally {
            setSaving(false);
        }
    };

    if (loading) return <Spin />;

    return (
        <Card size="small" title={<><SafetyCertificateOutlined /> Sécurité globale</>}>
            <Space>
                <Text>Activer la double authentification (2FA) pour les utilisateurs</Text>
                <Switch checked={enabled} loading={saving} onChange={toggle2FA} />
            </Space>
        </Card>
    );
}

// ════════════════════════════════════════════════════════════════════
// PAGE PRINCIPALE
// ════════════════════════════════════════════════════════════════════
export default function Admin() {
    const tabItems = [
        {
            key: 'stats',
            label: <><BarChartOutlined /> Statistiques</>,
            children: <AdminStatsTab />,
        },
        {
            key: 'users',
            label: <><UserOutlined /> Utilisateurs</>,
            children: <UsersTab />,
        },
        {
            key: 'plannings',
            label: <><CalendarOutlined /> Plannings</>,
            children: <AdminPlanningsTab />,
        },
        {
            key: 'rooms',
            label: <><BankOutlined /> Salles</>,
            children: <RoomsTab />,
        },
        {
            key: 'notifications',
            label: <><BellOutlined /> Notifications</>,
            children: <AdminNotifTab />,
        },
        {
            key: 'audit',
            label: <><FileTextOutlined /> Journaux d&apos;audit</>,
            children: <AdminAuditTab />,
        },
        {
            key: 'roles',
            label: <><SafetyCertificateOutlined /> Rôles & permissions</>,
            children: <RolesPermissionsTab />,
        },
        {
            key: 'security',
            label: <><SafetyCertificateOutlined /> Sécurité</>,
            children: <SecurityTab />,
        },
    ];

    return (
        <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 24 }}>
                <SettingOutlined style={{ fontSize: 22, color: '#1677ff' }} />
                <Title level={3} style={{ margin: 0 }}>Administration</Title>
            </div>

            <Card>
                <Tabs items={tabItems} defaultActiveKey="stats" />
            </Card>
        </div>
    );
}
