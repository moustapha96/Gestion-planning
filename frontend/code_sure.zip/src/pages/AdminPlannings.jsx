import { Card, Typography } from 'antd';
import { CalendarOutlined } from '@ant-design/icons';
import AdminPlanningsTab from './AdminPlanningsTab';

const { Title } = Typography;

export default function AdminPlannings() {
    return (
        <div>
            <Title level={3} style={{ marginBottom: 16 }}>
                <CalendarOutlined style={{ marginRight: 8 }} />
                Gestion des plannings
            </Title>
            <Card>
                <AdminPlanningsTab />
            </Card>
        </div>
    );
}
