import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { ConfigProvider, App as AntApp } from 'antd';
import './index.css';
import App from './App.jsx';
import { AuthProvider } from './context/AuthContext.jsx';

createRoot(document.getElementById('root')).render(
    <StrictMode>
        <ConfigProvider theme={{
            token: {
                colorPrimary: '#1A365D',
                colorSuccess: '#48BB78',
                colorLink: '#1A365D',
                borderRadius: 8,
                fontFamily: "'Segoe UI', system-ui, sans-serif",
            },
            components: {
                Button: { colorPrimary: '#1A365D', algorithm: true },
                Menu:   { colorItemBgSelected: '#e8f0fe', colorItemTextSelected: '#1A365D' },
            },
        }}>
            <AntApp>
                <AuthProvider>
                    <App />
                </AuthProvider>
            </AntApp>
        </ConfigProvider>
    </StrictMode>
);
