/**
 * NotificationBell — cloche dans le header.
 * Utilise le store Zustand (pas d'état local dupliqué).
 * Affiche NotificationPanel au clic.
 */
import { Badge, Button, Tooltip } from 'antd';
import { BellOutlined } from '@ant-design/icons';
import useNotificationStore from '../store/notificationStore';
import NotificationPanel from './NotificationPanel';

export default function NotificationBell() {
    const { unreadCount, panelOpen, togglePanel, closePanel } = useNotificationStore();

    return (
        <div style={{ position: 'relative' }}>
            <Tooltip title="Notifications" placement="bottom">
                <Badge
                    count={unreadCount}
                    overflowCount={99}
                    size="small"
                    offset={[-2, 2]}
                >
                    <Button
                        type="text"
                        icon={<BellOutlined style={{ fontSize: 20 }} />}
                        onClick={togglePanel}
                        style={{
                            width: 44,
                            height: 44,
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            color: panelOpen ? '#1677ff' : 'rgba(0,0,0,0.65)',
                            background: panelOpen ? '#e6f4ff' : 'transparent',
                            borderRadius: 8,
                        }}
                        aria-label={`Notifications${unreadCount > 0 ? ` (${unreadCount} non lues)` : ''}`}
                    />
                </Badge>
            </Tooltip>

            {panelOpen && <NotificationPanel onClose={closePanel} />}
        </div>
    );
}
