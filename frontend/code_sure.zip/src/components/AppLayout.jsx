import { useState, useEffect, useRef } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import {
    Layout, Menu, Dropdown, Space, App, Button,
    Drawer, Grid, Tag, Typography,
} from 'antd';
import {
    MenuFoldOutlined, MenuUnfoldOutlined, DashboardOutlined, CalendarOutlined,
    TeamOutlined, HomeOutlined, SettingOutlined, UserOutlined, LogoutOutlined,
    BellOutlined, FlagOutlined, ScheduleOutlined,
} from '@ant-design/icons';
import { useAuth } from '../context/AuthContext';
import NotificationBell from './NotificationBell';
import UserAvatar from './UserAvatar';
import useNotificationStore from '../store/notificationStore';
import api from '../api/client';

const { Header, Content, Sider } = Layout;
const { useBreakpoint } = Grid;
const { Text } = Typography;

const ROLE_LABELS = {
    RESPONSABLE:   'Responsable',
    CONSOLIDATEUR: 'Consolidateur',
    DG:            'Dir. Général',
    ADMIN:         'Administrateur',
};
const ROLE_COLORS = {
    RESPONSABLE:   'blue',
    CONSOLIDATEUR: 'purple',
    DG:            'gold',
    ADMIN:         'red',
};

export default function AppLayout() {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const { modal, notification } = App.useApp();
    const screens = useBreakpoint();
    const isMobile = !screens.md;
    const [drawerOpen, setDrawerOpen] = useState(false);
    const [collapsed, setCollapsed] = useState(() => {
        try { return localStorage.getItem('sidebarCollapsed') === 'true'; } catch { return false; }
    });

    const { startPolling, stopPolling } = useNotificationStore();
    const seenNotifIdsRef = useRef(new Set());

    // ── Démarrer / arrêter le polling des notifications ──────────
    useEffect(() => {
        if (user?.id) {
            startPolling();
        }
        return () => stopPolling();
    }, [user?.id]);

    // ── Popup instantané des nouvelles notifications (sans refresh manuel)
    useEffect(() => {
        if (!user?.id) return;
        let mounted = true;

        const checkNewNotifications = async () => {
            try {
                const { data } = await api.get('/notifications', { params: { page: 1, limit: 10 } });
                if (!mounted) return;
                const list = data?.notifications || [];

                // Initialisation silencieuse: ne pas popper les anciennes notifs déjà présentes
                if (seenNotifIdsRef.current.size === 0) {
                    list.forEach((n) => seenNotifIdsRef.current.add(n.id));
                    return;
                }

                const freshUnread = list
                    .filter((n) => !n.isRead && !seenNotifIdsRef.current.has(n.id))
                    .reverse(); // du plus ancien au plus récent pour un affichage naturel

                freshUnread.forEach((n) => {
                    notification.open({
                        key: `notif-${n.id}`,
                        message: n.title || 'Nouvelle notification',
                        description: n.body || '',
                        placement: 'topRight',
                        duration: 6,
                        onClick: () => {
                            if (n.link) navigate(n.link);
                        },
                    });
                });

                list.forEach((n) => seenNotifIdsRef.current.add(n.id));
            } catch {
                // silencieux: ne pas spammer l'utilisateur
            }
        };

        checkNewNotifications();
        const timer = setInterval(checkNewNotifications, 5000);
        return () => {
            mounted = false;
            clearInterval(timer);
        };
    }, [user?.id, notification, navigate]);

    // ── Fermer le drawer mobile à chaque changement de route ─────
    useEffect(() => {
        if (isMobile) setDrawerOpen(false);
    }, [location.pathname, isMobile]);

    const toggleSidebar = () => {
        if (isMobile) { setDrawerOpen((o) => !o); return; }
        const next = !collapsed;
        setCollapsed(next);
        try { localStorage.setItem('sidebarCollapsed', String(next)); } catch {}
    };

    const goTo = (path) => {
        navigate(path);
        if (isMobile) setDrawerOpen(false);
    };

    // ── Éléments du menu sidebar ──────────────────────────────────
    const menuItems = [
        {
            key: '/dashboard',
            icon: <DashboardOutlined />,
            label: 'Tableau de bord',
        },
        {
            key: '/calendar',
            icon: <CalendarOutlined />,
            label: 'Calendrier',
        },
        {
            key: '/planning',
            icon: <ScheduleOutlined />,
            label: 'Planning',
        },
        {
            key: '/meetings',
            icon: <TeamOutlined />,
            label: 'Réunions',
        },
        {
            key: '/missions',
            icon: <FlagOutlined />,
            label: 'Missions',
        },
        {
            key: '/rooms',
            icon: <HomeOutlined />,
            label: 'Salles',
        },
        {
            key: '/notifications',
            icon: <BellOutlined />,
            label: 'Notifications',
        },
        // Section admin — séparée visuellement
        ...(user?.role === 'ADMIN' ? [
            { type: 'divider' },
            {
                key: '/admin',
                icon: <SettingOutlined />,
                label: 'Administration',
            },
        ] : []),
    ];

    // ── Menu utilisateur (dropdown en-tête) ───────────────────────
    const userMenuItems = [
        {
            key: 'user-info',
            disabled: true,
            label: (
                <div style={{ padding: '6px 0', pointerEvents: 'none', display: 'flex', gap: 12, alignItems: 'center' }}>
                    <UserAvatar user={user} size={40} />
                    <div>
                        <Text strong style={{ display: 'block', fontSize: 14 }}>{user?.name}</Text>
                        <Text type="secondary" style={{ fontSize: 12 }}>{user?.email}</Text>
                        <div style={{ marginTop: 3 }}>
                            <Tag color={ROLE_COLORS[user?.role]} style={{ fontSize: 11, margin: 0 }}>
                                {ROLE_LABELS[user?.role] || user?.role}
                            </Tag>
                        </div>
                    </div>
                </div>
            ),
        },
        { type: 'divider' },
        {
            key: 'profile',
            icon: <UserOutlined />,
            label: 'Mon profil',
            onClick: () => navigate('/profile'),
        },
        { type: 'divider' },
        {
            key: 'logout',
            icon: <LogoutOutlined />,
            label: 'Se déconnecter',
            danger: true,
            onClick: () => {
                modal.confirm({
                    title: 'Se déconnecter',
                    content: 'Êtes-vous sûr de vouloir vous déconnecter ?',
                    okText: 'Se déconnecter',
                    cancelText: 'Annuler',
                    onOk: () => { logout(); navigate('/login'); },
                });
            },
        },
    ];

    // ── Contenu du menu sidebar (desktop + drawer mobile) ─────────
    const menuContent = (
        <>
            {/* Logo / titre */}
            <div
                style={{
                    height: 56,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: isMobile || !collapsed ? 'flex-start' : 'center',
                    paddingLeft: isMobile ? 20 : collapsed ? 0 : 20,
                    borderBottom: '1px solid rgba(255,255,255,0.08)',
                    flexShrink: 0,
                }}
            >
                {(!collapsed || isMobile) ? (
                    <span
                        role="button"
                        tabIndex={0}
                        style={{
                            color: 'white',
                            fontWeight: 700,
                            fontSize: 15,
                            cursor: 'pointer',
                            whiteSpace: 'nowrap',
                            letterSpacing: '0.02em',
                        }}
                        onClick={() => goTo('/dashboard')}
                        onKeyDown={(e) => e.key === 'Enter' && goTo('/dashboard')}
                    >
                        📅 Gestion Planning
                    </span>
                ) : (
                    <span
                        role="button"
                        tabIndex={0}
                        style={{ fontSize: 20, cursor: 'pointer' }}
                        onClick={() => goTo('/dashboard')}
                        onKeyDown={(e) => e.key === 'Enter' && goTo('/dashboard')}
                    >
                        📅
                    </span>
                )}
            </div>

            {/* Menu */}
            <div style={{ flex: 1, overflow: 'auto' }}>
                <Menu
                    theme="dark"
                    mode="inline"
                    selectedKeys={[location.pathname]}
                    items={menuItems.map((item) =>
                        item.type === 'divider'
                            ? { type: 'divider', style: { borderColor: 'rgba(255,255,255,0.08)', margin: '4px 0' } }
                            : { ...item, onClick: () => goTo(item.key) }
                    )}
                    style={{ borderRight: 0, marginTop: 4, background: 'transparent' }}
                    inlineCollapsed={!isMobile && collapsed}
                />
            </div>

            {/* Profil en bas du sidebar */}
            {!collapsed && !isMobile && (
                <div style={{
                    borderTop: '1px solid rgba(255,255,255,0.08)',
                    padding: '12px 16px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    background: 'rgba(255,255,255,0.04)',
                }}>
                    <UserAvatar user={user} size={32} />
                    <div style={{ minWidth: 0 }}>
                        <Text style={{ color: 'rgba(255,255,255,0.9)', fontSize: 13, fontWeight: 500, display: 'block' }}>
                            {user?.name}
                        </Text>
                        <Tag
                            color={ROLE_COLORS[user?.role]}
                            style={{ fontSize: 10, padding: '0 4px', lineHeight: '16px', marginTop: 2 }}
                        >
                            {ROLE_LABELS[user?.role] || user?.role}
                        </Tag>
                    </div>
                </div>
            )}
        </>
    );

    return (
        <Layout style={{ minHeight: '100vh' }}>
            {/* ── Sidebar desktop ── */}
            {!isMobile && (
                <Sider
                    theme="dark"
                    collapsible
                    collapsed={collapsed}
                    onCollapse={setCollapsed}
                    trigger={null}
                    width={220}
                    collapsedWidth={64}
                    style={{
                        overflow: 'hidden',
                        height: '100vh',
                        position: 'fixed',
                        left: 0, top: 0, bottom: 0,
                        zIndex: 100,
                        display: 'flex',
                        flexDirection: 'column',
                    }}
                >
                    {menuContent}
                </Sider>
            )}

            {/* ── Drawer mobile ── */}
            {isMobile && (
                <Drawer
                    title={null}
                    placement="left"
                    onClose={() => setDrawerOpen(false)}
                    open={drawerOpen}
                    styles={{ body: { padding: 0, background: '#001529', display: 'flex', flexDirection: 'column', height: '100%' } }}
                    width={260}
                >
                    {menuContent}
                </Drawer>
            )}

            {/* ── Contenu principal ── */}
            <Layout style={{
                marginLeft: isMobile ? 0 : collapsed ? 64 : 220,
                minHeight: '100vh',
                transition: 'margin-left 0.2s',
            }}>
                {/* ── Header ── */}
                <Header style={{
                    display: 'flex',
                    alignItems: 'center',
                    padding: isMobile ? '0 8px 0 12px' : '0 24px 0 0',
                    background: '#fff',
                    borderBottom: '1px solid #f0f0f0',
                    height: 56,
                    gap: 8,
                    position: 'sticky',
                    top: 0,
                    zIndex: 99,
                }}>
                    {/* Bouton toggle sidebar */}
                    <Button
                        type="text"
                        icon={
                            isMobile
                                ? (drawerOpen ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />)
                                : (collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />)
                        }
                        onClick={toggleSidebar}
                        style={{ fontSize: 18, width: 44, height: 44 }}
                        title={collapsed || !drawerOpen ? 'Ouvrir le menu' : 'Fermer le menu'}
                    />

                    {/* Breadcrumb de la page courante (mobile) */}
                    {isMobile && (
                        <Text strong style={{ flex: 1, fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {menuItems.find((m) => m.key === location.pathname)?.label || ''}
                        </Text>
                    )}

                    <div style={{ flex: 1 }} />

                    <Space size={isMobile ? 4 : 8}>
                        {/* Cloche notifications */}
                        <NotificationBell />

                        {/* Avatar + menu utilisateur */}
                        <Dropdown
                            menu={{ items: userMenuItems }}
                            placement="bottomRight"
                            trigger={['click']}
                        >
                            <Space
                                style={{
                                    cursor: 'pointer',
                                    padding: '6px 10px',
                                    borderRadius: 8,
                                    minHeight: 44,
                                    transition: 'background 0.15s',
                                }}
                                onMouseEnter={(e) => { e.currentTarget.style.background = '#f5f5f5'; }}
                                onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; }}
                            >
                                <UserAvatar user={user} size={28} />
                                {!isMobile && (
                                    <div style={{ display: 'flex', flexDirection: 'column', gap: 0, lineHeight: 1.2 }}>
                                        <Text style={{ fontSize: 13, fontWeight: 500 }}>{user?.name}</Text>
                                        <Tag
                                            color={ROLE_COLORS[user?.role]}
                                            style={{ fontSize: 10, padding: '0 4px', lineHeight: '14px', margin: 0 }}
                                        >
                                            {ROLE_LABELS[user?.role] || user?.role}
                                        </Tag>
                                    </div>
                                )}
                            </Space>
                        </Dropdown>
                    </Space>
                </Header>

                {/* ── Page ── */}
                <Content
                    style={{
                        padding: isMobile ? 12 : 24,
                        background: '#f5f5f5',
                        minHeight: 'calc(100vh - 56px)',
                        overflow: 'auto',
                        WebkitOverflowScrolling: 'touch',
                    }}
                >
                    <Outlet />
                </Content>
            </Layout>
        </Layout>
    );
}
