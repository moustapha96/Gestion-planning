import { useNavigate, useLocation } from 'react-router-dom';
import NotificationBell from './NotificationBell';

const NAV_ITEM = 'px-3 py-1.5 rounded-md text-sm font-medium transition-all duration-150 hover:bg-white/15';
const NAV_ACTIVE = 'bg-white/20 text-white font-semibold';

export default function Navbar({ user }) {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path) => location.pathname.startsWith(path);

  const handleLogout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <nav style={{ background: 'linear-gradient(135deg, #1A365D 0%, #1e4d8c 100%)' }}
         className="text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 py-2 flex justify-between items-center gap-4">

        {/* Logo + titre */}
        <button
          onClick={() => navigate('/dashboard')}
          className="flex items-center gap-2 shrink-0 hover:opacity-90 transition-opacity"
          style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
        >
          <img src="/favicon.svg" alt="logo" style={{ width: 36, height: 36 }} />
          <div className="leading-tight hidden sm:block">
            <div style={{ fontSize: 15, fontWeight: 800, color: 'white', lineHeight: 1.1 }}>Gestion</div>
            <div style={{ fontSize: 15, fontWeight: 800, color: '#48BB78', lineHeight: 1.1 }}>Planning</div>
          </div>
        </button>

        {/* Navigation centrale */}
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-hide flex-1 justify-center">
          <button onClick={() => navigate('/dashboard')}
            className={`${NAV_ITEM} ${isActive('/dashboard') ? NAV_ACTIVE : 'text-blue-100'}`}>
            Tableau de bord
          </button>

          {user?.role !== 'ADMIN' && (
            <>
              <button onClick={() => navigate('/planning')}
                className={`${NAV_ITEM} ${isActive('/planning') ? NAV_ACTIVE : 'text-blue-100'}`}>
                Planning
              </button>
              <button onClick={() => navigate('/meetings')}
                className={`${NAV_ITEM} ${isActive('/meetings') ? NAV_ACTIVE : 'text-blue-100'}`}>
                Réunions
              </button>
              <button onClick={() => navigate('/missions')}
                className={`${NAV_ITEM} ${isActive('/missions') ? NAV_ACTIVE : 'text-blue-100'}`}>
                Missions
              </button>
            </>
          )}

          <button onClick={() => navigate('/rooms')}
            className={`${NAV_ITEM} ${isActive('/rooms') ? NAV_ACTIVE : 'text-blue-100'}`}>
            Salles
          </button>
          <button onClick={() => navigate('/calendar')}
            className={`${NAV_ITEM} ${isActive('/calendar') ? NAV_ACTIVE : 'text-blue-100'}`}>
            Calendrier
          </button>

          {user?.role === 'ADMIN' && (
            <button onClick={() => navigate('/admin')}
              className={`${NAV_ITEM} ${isActive('/admin') ? NAV_ACTIVE : 'text-blue-100'}`}>
              Admin
            </button>
          )}
        </div>

        {/* Droite : notif + user + logout */}
        <div className="flex items-center gap-2 shrink-0">
          <NotificationBell />

          <button onClick={() => navigate('/profile')}
            className="flex items-center gap-1.5 hover:bg-white/15 px-2 py-1 rounded-md transition-all"
            style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
            <div
              style={{
                width: 28, height: 28, borderRadius: '50%',
                background: '#48BB78',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontWeight: 700, fontSize: 13, color: '#1A365D', flexShrink: 0,
              }}
            >
              {user?.name?.[0]?.toUpperCase() || '?'}
            </div>
            <span className="text-xs text-blue-100 hidden md:block max-w-25 truncate">
              {user?.name}
            </span>
          </button>

          <button
            onClick={handleLogout}
            className="text-xs font-medium px-3 py-1.5 rounded-md transition-all"
            style={{ background: 'rgba(255,255,255,0.12)', border: '1px solid rgba(255,255,255,0.2)', color: 'white', cursor: 'pointer' }}
            onMouseOver={e => e.currentTarget.style.background = 'rgba(255,255,255,0.22)'}
            onMouseOut={e => e.currentTarget.style.background = 'rgba(255,255,255,0.12)'}
          >
            Déconnexion
          </button>
        </div>
      </div>
    </nav>
  );
}
