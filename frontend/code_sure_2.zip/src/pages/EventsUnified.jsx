import { useEffect, useMemo, useState } from 'react';
import { Card, Col, Empty, Input, Row, Select, Space, Spin, Table, Tag, Typography } from 'antd';
import { Link } from 'react-router-dom';
import api from '../api/client';

const { Title, Text } = Typography;

const SOURCE_LABELS = {
    MEETING: 'Reunion',
    MISSION: 'Mission',
    PLANNING_EVENT: 'Planning',
};

export default function EventsUnified() {
    const [loading, setLoading] = useState(false);
    const [items, setItems] = useState([]);
    const [total, setTotal] = useState(0);
    const [filtersMeta, setFiltersMeta] = useState({ directions: [], projects: [], eventTypes: [] });
    const [q, setQ] = useState('');
    const [sourceType, setSourceType] = useState(undefined);
    const [eventType, setEventType] = useState(undefined);
    const [directionId, setDirectionId] = useState(undefined);
    const [projectId, setProjectId] = useState(undefined);
    const [from, setFrom] = useState('');
    const [to, setTo] = useState('');
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(25);

    const load = async () => {
        setLoading(true);
        try {
            const { data } = await api.get('/events/unified', {
                params: {
                    q: q || undefined,
                    source: sourceType || undefined,
                    eventType: eventType || undefined,
                    directionId: directionId || undefined,
                    projectId: projectId || undefined,
                    from: from || undefined,
                    to: to || undefined,
                    page,
                    limit: pageSize,
                },
            });
            setItems(data?.items || []);
            setTotal(data?.total || 0);
            setFiltersMeta(data?.filtersMeta || { directions: [], projects: [], eventTypes: [] });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        load();
    }, [q, sourceType, eventType, directionId, projectId, from, to, page, pageSize]);

    const columns = useMemo(() => ([
        {
            title: 'Type',
            dataIndex: 'sourceType',
            key: 'sourceType',
            width: 120,
            render: (v) => <Tag>{SOURCE_LABELS[v] || v}</Tag>,
        },
        {
            title: 'Evenement',
            key: 'title',
            render: (_, row) => (
                <Space orientation="vertical" size={0}>
                    <Link to={row.link}><Text strong>{row.title}</Text></Link>
                    <Text type="secondary">{row.description || '-'}</Text>
                </Space>
            ),
        },
        {
            title: 'Date debut',
            dataIndex: 'startAt',
            key: 'startAt',
            width: 180,
            render: (v) => (v ? new Date(v).toLocaleString('fr-FR') : '-'),
        },
        {
            title: 'Lieu',
            dataIndex: 'location',
            key: 'location',
            width: 180,
            render: (v) => v || '-',
        },
        {
            title: 'Direction',
            key: 'direction',
            width: 160,
            render: (_, row) => row.direction?.name || '-',
        },
        {
            title: 'Projet',
            key: 'project',
            width: 160,
            render: (_, row) => row.project?.name || '-',
        },
        {
            title: 'Responsable',
            key: 'responsible',
            width: 200,
            render: (_, row) => row.responsibleUsers?.[0]?.name || '-',
        },
        {
            title: 'Participants',
            dataIndex: 'participantsCount',
            key: 'participantsCount',
            width: 110,
        },
        {
            title: 'Statut',
            dataIndex: 'status',
            key: 'status',
            width: 140,
        },
    ]), []);

    return (
        <div>
            <Title level={3} style={{ marginTop: 0 }}>Evenements unifies</Title>
            <Card style={{ marginBottom: 16 }}>
                <Row gutter={[12, 12]}>
                    <Col xs={24} md={6}>
                        <Input.Search
                            allowClear
                            placeholder="Rechercher titre, description, responsable..."
                            value={q}
                            onChange={(e) => { setPage(1); setQ(e.target.value); }}
                        />
                    </Col>
                    <Col xs={24} md={3}>
                        <Select
                            allowClear
                            style={{ width: '100%' }}
                            placeholder="Direction"
                            value={directionId}
                            onChange={(v) => { setPage(1); setDirectionId(v); }}
                            options={(filtersMeta.directions || []).map((x) => ({ value: x.id, label: x.code ? `${x.name} (${x.code})` : x.name }))}
                        />
                    </Col>
                    <Col xs={24} md={3}>
                        <Select
                            allowClear
                            style={{ width: '100%' }}
                            placeholder="Projet"
                            value={projectId}
                            onChange={(v) => { setPage(1); setProjectId(v); }}
                            options={(filtersMeta.projects || []).map((x) => ({ value: x.id, label: x.code ? `${x.name} (${x.code})` : x.name }))}
                        />
                    </Col>
                    <Col xs={24} md={3}>
                        <Select
                            allowClear
                            style={{ width: '100%' }}
                            placeholder="Source"
                            value={sourceType}
                            onChange={(v) => { setPage(1); setSourceType(v); }}
                            options={(filtersMeta.sourceTypes || []).map((x) => ({ value: x, label: SOURCE_LABELS[x] || x }))}
                        />
                    </Col>
                    <Col xs={24} md={3}>
                        <Select
                            allowClear
                            style={{ width: '100%' }}
                            placeholder="Type evenement"
                            value={eventType}
                            onChange={(v) => { setPage(1); setEventType(v); }}
                            options={(filtersMeta.eventTypes || []).map((x) => ({ value: x, label: x }))}
                        />
                    </Col>
                    <Col xs={12} md={3}>
                        <input
                            type="date"
                            value={from}
                            onChange={(e) => { setPage(1); setFrom(e.target.value); }}
                            style={{ width: '100%', height: 32 }}
                        />
                    </Col>
                    <Col xs={12} md={3}>
                        <input
                            type="date"
                            value={to}
                            onChange={(e) => { setPage(1); setTo(e.target.value); }}
                            style={{ width: '100%', height: 32 }}
                        />
                    </Col>
                </Row>
                <div style={{ marginTop: 8 }}><Text type="secondary">Filtres avances actifs: source, type, direction, projet, periode.</Text></div>
            </Card>

            <Spin spinning={loading}>
                {items.length === 0 ? (
                    <Card><Empty description="Aucun evenement trouve" /></Card>
                ) : (
                    <Card>
                        <Table
                            rowKey="id"
                            dataSource={items}
                            columns={columns}
                            pagination={{
                                current: page,
                                pageSize,
                                total,
                                showSizeChanger: true,
                                onChange: (p, s) => {
                                    setPage(p);
                                    setPageSize(s);
                                },
                            }}
                            scroll={{ x: 'max-content' }}
                        />
                    </Card>
                )}
            </Spin>
        </div>
    );
}
