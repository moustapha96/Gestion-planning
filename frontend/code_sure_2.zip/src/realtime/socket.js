import { io } from 'socket.io-client';
import { API_BASE } from '../api/client';

let socketInstance = null;
let socketListenersBound = false;
const statusSubscribers = new Set();
const actionQueue = [];
let isFlushingQueue = false;
const socketStatus = {
    connected: false,
    reconnecting: false,
    lastDisconnectReason: null,
};

function socketUrl() {
    return API_BASE || window.location.origin;
}

function emitStatus() {
    statusSubscribers.forEach((cb) => {
        try { cb({ ...socketStatus }); } catch { /* ignore subscriber errors */ }
    });
}

function isNetworkError(err) {
    return !err?.response;
}

async function flushQueuedActions() {
    if (isFlushingQueue || !socketStatus.connected || actionQueue.length === 0) return;
    isFlushingQueue = true;
    try {
        while (actionQueue.length > 0 && socketStatus.connected) {
            const task = actionQueue[0];
            try {
                await task.run({ fromQueue: true });
                actionQueue.shift();
            } catch (err) {
                if (isNetworkError(err)) break;
                actionQueue.shift();
            }
        }
    } finally {
        isFlushingQueue = false;
    }
}

function bindSocketListeners() {
    if (!socketInstance || socketListenersBound) return;
    socketListenersBound = true;
    socketInstance.on('connect', () => {
        socketStatus.connected = true;
        socketStatus.reconnecting = false;
        socketStatus.lastDisconnectReason = null;
        emitStatus();
        flushQueuedActions();
    });
    socketInstance.on('connect_error', () => {
        socketStatus.connected = false;
        socketStatus.reconnecting = true;
        socketStatus.lastDisconnectReason = 'connect_error';
        emitStatus();
    });
    socketInstance.on('disconnect', (reason) => {
        socketStatus.connected = false;
        const manual = reason === 'io client disconnect' || reason === 'io server disconnect';
        socketStatus.reconnecting = !manual;
        socketStatus.lastDisconnectReason = reason || 'disconnect';
        emitStatus();
    });
    socketInstance.io.on('reconnect_attempt', () => {
        socketStatus.reconnecting = true;
        emitStatus();
    });
    socketInstance.io.on('reconnect', () => {
        socketStatus.connected = true;
        socketStatus.reconnecting = false;
        socketStatus.lastDisconnectReason = null;
        emitStatus();
        flushQueuedActions();
    });
    socketInstance.io.on('reconnect_failed', () => {
        socketStatus.connected = false;
        socketStatus.reconnecting = false;
        emitStatus();
    });
    if (socketInstance.connected) {
        socketStatus.connected = true;
        socketStatus.reconnecting = false;
        emitStatus();
    }
}

export function getSocket(token) {
    if (!token) return null;
    if (socketInstance) {
        const current = socketInstance.auth?.token;
        if (current !== token) {
            socketInstance.auth = { token };
            if (!socketInstance.connected) socketInstance.connect();
        }
        bindSocketListeners();
        return socketInstance;
    }

    socketInstance = io(socketUrl(), {
        transports: ['websocket'],
        autoConnect: true,
        auth: { token },
    });
    bindSocketListeners();
    if (socketInstance.connected) {
        socketStatus.connected = true;
        socketStatus.reconnecting = false;
        emitStatus();
    }
    return socketInstance;
}

export function subscribeSocketStatus(callback) {
    if (typeof callback !== 'function') return () => {};
    statusSubscribers.add(callback);
    callback({ ...socketStatus });
    return () => statusSubscribers.delete(callback);
}

export function getSocketStatusSnapshot() {
    return { ...socketStatus };
}

export function isSocketConnected() {
    return Boolean(socketStatus.connected);
}

export function enqueueRealtimeTask(run, meta = {}) {
    if (typeof run !== 'function') return;
    actionQueue.push({ run, meta });
}

export function disconnectSocket() {
    if (!socketInstance) return;
    socketInstance.disconnect();
    socketInstance = null;
    socketListenersBound = false;
    socketStatus.connected = false;
    socketStatus.reconnecting = false;
    socketStatus.lastDisconnectReason = null;
    emitStatus();
}
