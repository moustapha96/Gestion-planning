import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import AppLayout from './components/AppLayout';
import Login from './pages/Login';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import ActivateAccount from './pages/ActivateAccount';
import Dashboard from './pages/Dashboard';
import Planning from './pages/Planning';
import Meetings from './pages/Meetings';
import Missions from './pages/Missions';
import MissionCreate from './pages/MissionCreate';
import MissionEdit from './pages/MissionEdit';
import Rooms from './pages/Rooms';
import Admin from './pages/Admin';
import AdminPlannings from './pages/AdminPlannings';
import Profile from './pages/Profile';
import Calendar from './pages/Calendar';
import MeetingDetail from './pages/MeetingDetail';
import MissionDetail from './pages/MissionDetail';
import PlanningDetail from './pages/PlanningDetail';
import Notifications from './pages/Notifications';
import Discussions from './pages/Discussions';
import EventsUnified from './pages/EventsUnified';
import Users from './pages/Users';
import Logs from './pages/Logs';
import Projects from './pages/Projects';
import NotFound from './pages/NotFound';
import Home from './pages/Home';
import PWAInstallPrompt from './components/PWAInstallPrompt';
import MobileInit from './components/MobileInit';

function ProtectedRoute() {
    const { user } = useAuth();
    if (!user) return <Navigate to="/login" replace />;
    return <Outlet />;
}

function AdminRoute() {
    const { user } = useAuth();
    if (user?.role !== 'ADMIN') return <Navigate to="/dashboard" replace />;
    return <Outlet />;
}

export default function App() {
    return (
        <BrowserRouter>
            <MobileInit />
            <PWAInstallPrompt />
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/forgot-password" element={<ForgotPassword />} />
                <Route path="/reset-password" element={<ResetPassword />} />
                <Route path="/activate-account" element={<ActivateAccount />} />
                <Route path="/" element={<Home />} />
                <Route element={<ProtectedRoute />}>
                    <Route element={<AppLayout />}>
                        <Route path="/dashboard" element={<Dashboard />} />
                        <Route path="/planning" element={<Planning />} />
                        <Route path="/planning/:id" element={<PlanningDetail />} />
                        <Route path="/plannings/:id" element={<PlanningDetail />} />
                        <Route path="/meetings" element={<Meetings />} />
                        <Route path="/meetings/:id" element={<MeetingDetail />} />
                        <Route path="/missions" element={<Missions />} />
                        <Route path="/missions/new" element={<MissionCreate />} />
                        <Route path="/missions/:id/edit" element={<MissionEdit />} />
                        <Route path="/missions/:id" element={<MissionDetail />} />
                        <Route path="/rooms" element={<Rooms />} />
                        <Route path="/projects" element={<Projects />} />
                        <Route path="/calendar" element={<Calendar />} />
                        <Route path="/notifications" element={<Notifications />} />
                        <Route path="/discussions" element={<Discussions />} />
                        <Route path="/events" element={<EventsUnified />} />
                        <Route path="/profile" element={<Profile />} />
                        <Route element={<AdminRoute />}>
                            <Route path="/admin" element={<Admin />} />
                            <Route path="/admin/plannings" element={<AdminPlannings />} />
                            <Route path="/users" element={<Users />} />
                            <Route path="/logs" element={<Logs />} />
                        </Route>
                    </Route>
                </Route>
                <Route path="*" element={<NotFound />} />
            </Routes>
        </BrowserRouter>
    );
}
