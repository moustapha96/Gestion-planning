const express = require('express');
const router = express.Router();

function startOfDay(d) {
    const x = new Date(d);
    x.setHours(0, 0, 0, 0);
    return x;
}

function endOfDay(d) {
    const x = new Date(d);
    x.setHours(23, 59, 59, 999);
    return x;
}

// GET /api/public/day-planning - Planning de la journée pour toutes les salles (public)
router.get('/day-planning', async (req, res) => {
    try {
        if (!req.prisma) {
            return res.status(200).json({ rooms: [], date: new Date().toISOString() });
        }
        const todayStart = startOfDay(new Date());
        const todayEnd = endOfDay(new Date());

        const rooms = await req.prisma.room.findMany({
            where: { status: 'ACTIVE' },
            include: {
                bookings: {
                    where: {
                        status: 'CONFIRMED',
                        date: {
                            gte: todayStart,
                            lte: todayEnd,
                        },
                    },
                    include: { meeting: { select: { id: true, title: true } } },
                    orderBy: { createdAt: 'asc' },
                },
            },
            orderBy: { name: 'asc' },
        });

        const roomsWithBookings = (rooms || []).map((r) => ({
            id: r.id,
            name: r.name,
            capacity: r.capacity,
            location: r.location || '',
            bookings: (r.bookings || []).map((b) => ({
                id: b.id,
                startTime: b.startTime,
                endTime: b.endTime,
                meetingTitle: (b.meeting && b.meeting.title) || null,
                meetingId: b.meetingId,
            })),
        }));

        const missions = await req.prisma.mission.findMany({
            where: {
                status: { not: 'CANCELLED' },
                startTime: { gte: todayStart, lte: todayEnd },
            },
            include: { createdBy: { select: { name: true } } },
            orderBy: { startTime: 'asc' },
        });

        res.status(200).json({
            date: todayStart.toISOString(),
            rooms: roomsWithBookings,
            missions: missions || [],
        });
    } catch (error) {
        res.status(200).json({ rooms: [], date: new Date().toISOString() });
    }
});

module.exports = router;

