const express = require('express');
const { logger } = require('../utils/logger');
const { createAuditLog } = require('../utils/audit');
const { ROLES } = require('../config/roles');

const router = express.Router();

const ALLOWED_KEYS = ['2fa_enabled'];

/**
 * GET /api/admin/settings
 * Retourne tous les paramètres globaux (ADMIN uniquement)
 */
router.get('/', async (req, res) => {
    try {
        if (req.user?.role !== ROLES.ADMIN) {
            return res.status(403).json({ error: 'Accès réservé aux administrateurs.' });
        }
        const rows = await req.prisma.appSetting.findMany();
        const settings = Object.fromEntries(rows.map((r) => [r.key, r.value]));
        // Valeurs par défaut
        if (!('2fa_enabled' in settings)) settings['2fa_enabled'] = 'false';
        res.json(settings);
    } catch (error) {
        logger.error('GET_ADMIN_SETTINGS', error.message, { userId: req.user?.id });
        res.status(500).json({ error: error.message });
    }
});

/**
 * PUT /api/admin/settings
 * Met à jour un ou plusieurs paramètres (ADMIN uniquement)
 * Body: { "2fa_enabled": "true" | "false", ... }
 */
router.put('/', async (req, res) => {
    try {
        if (req.user?.role !== ROLES.ADMIN) {
            return res.status(403).json({ error: 'Accès réservé aux administrateurs.' });
        }
        const body = req.body || {};
        const updates = [];

        for (const key of ALLOWED_KEYS) {
            if (key in body) {
                const value = String(body[key]);
                updates.push(
                    req.prisma.appSetting.upsert({
                        where: { key },
                        update: { value },
                        create: { key, value },
                    })
                );
            }
        }

        if (!updates.length) {
            return res.status(400).json({ error: 'Aucun paramètre valide fourni.' });
        }

        await Promise.all(updates);

        const rows = await req.prisma.appSetting.findMany();
        const settings = Object.fromEntries(rows.map((r) => [r.key, r.value]));

        await createAuditLog(
            req, 'ADMIN_SETTINGS_UPDATED', 'AppSetting', 'global',
            `Paramètres mis à jour : ${Object.keys(body).join(', ')}`
        );
        logger.info('ADMIN_SETTINGS_UPDATED', 'Paramètres modifiés', { userId: req.user.id, keys: Object.keys(body) });

        res.json(settings);
    } catch (error) {
        logger.error('PUT_ADMIN_SETTINGS', error.message, { userId: req.user?.id });
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
