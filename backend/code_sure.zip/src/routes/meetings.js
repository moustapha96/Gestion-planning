const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const roleMiddleware = require('../middlewares/role.middleware');
const { notificationService } = require('../services/notification.service');
const { logger } = require('../utils/logger');
const { isRoomAvailableForSlot, isRoomActive } = require('../utils/availability');
const { createAuditLog } = require('../utils/audit');
const { ROLES } = require('../config/roles');

const router = express.Router();
let meetingFilesFeatureChecked = false;
let meetingFilesFeatureEnabled = false;

async function canUseMeetingFiles(prisma) {
    if (meetingFilesFeatureChecked) return meetingFilesFeatureEnabled;
    try {
        await prisma.meetingFile.count({ take: 1 });
        meetingFilesFeatureEnabled = true;
    } catch {
        meetingFilesFeatureEnabled = false;
    } finally {
        meetingFilesFeatureChecked = true;
    }
    return meetingFilesFeatureEnabled;
}

function canViewMeeting(meeting, user) {
    if (!meeting || !user) return false;
    // Tout utilisateur authentifié peut voir le détail d'une réunion
    // (le calendrier expose déjà toutes les réunions à tous les utilisateurs)
    return true;
}

async function getUserMeetingConflict(prisma, userId, start, end, excludeMeetingId = null) {
    return prisma.meeting.findFirst({
        where: {
            status: { not: 'CANCELLED' },
            ...(excludeMeetingId ? { id: { not: excludeMeetingId } } : {}),
            startTime: { lt: end },
            endTime: { gt: start },
            invitations: { some: { userId } },
        },
        select: { id: true, title: true, startTime: true, endTime: true },
    });
}

async function getUserMissionConflictForMeeting(prisma, userId, start, end) {
    return prisma.mission.findFirst({
        where: {
            status: { not: 'CANCELLED' },
            startTime: { lt: end },
            endTime: { gt: start },
            OR: [
                { createdById: userId },
                { assignments: { some: { userId } } },
            ],
        },
        select: { id: true, title: true, startTime: true, endTime: true },
    });
}

function canEditMeeting(meeting, user) {
    if (!meeting || !user) return false;
    return meeting.organizerId === user.id || user.role === ROLES.ADMIN;
}

function isParticipant(meeting, user) {
    if (!meeting || !user) return false;
    return (
        meeting.organizerId === user.id ||
        meeting.invitations?.some((inv) => inv.userId === user.id) ||
        user.role === ROLES.ADMIN
    );
}

function normalizeMeetingLink(value) {
    const raw = String(value || '').trim();
    if (!raw) return null;
    try {
        const parsed = new URL(raw);
        if (!['http:', 'https:'].includes(parsed.protocol)) return null;
        return parsed.toString();
    } catch {
        return null;
    }
}

const meetingsUploadDir = path.join(__dirname, '../../uploads/meetings');
const uploadMeetingFile = multer({
    storage: multer.diskStorage({
        destination(_req, _file, cb) {
            fs.mkdirSync(meetingsUploadDir, { recursive: true });
            cb(null, meetingsUploadDir);
        },
        filename(req, file, cb) {
            const ext = (path.extname(file.originalname) || '').toLowerCase().slice(0, 10) || '.bin';
            const safe = `${req.params.id}_${Date.now()}${ext}`;
            cb(null, safe);
        },
    }),
    limits: { fileSize: 15 * 1024 * 1024 },
});

/**
 * @swagger
 * tags:
 *   name: Meetings
 *   description: Gestion des réunions et convocations
 */

/**
 * @swagger
 * /api/meetings:
 *   get:
 *     summary: Lister les réunions de l'utilisateur
 *     tags: [Meetings]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Liste des réunions
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 allOf:
 *                   - $ref: '#/components/schemas/Meeting'
 *                   - type: object
 *                     properties:
 *                       organizer:
 *                         $ref: '#/components/schemas/User'
 *                       room:
 *                         $ref: '#/components/schemas/Room'
 *                       invitations:
 *                         type: array
 *                         items:
 *                           $ref: '#/components/schemas/Invitation'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 */
router.get('/', async (req, res) => {
    try {
        const includeFiles = await canUseMeetingFiles(req.prisma);
        const meetings = await req.prisma.meeting.findMany({
            where: {
                OR: [
                    { organizerId: req.user.id },
                    { invitations: { some: { userId: req.user.id } } },
                ],
            },
            include: {
                organizer: { select: { name: true, email: true } },
                room: true,
                invitations: { include: { user: true } },
                ...(includeFiles
                    ? {
                          files: {
                              include: { uploadedBy: { select: { id: true, name: true, email: true } } },
                              orderBy: { createdAt: 'desc' },
                          },
                      }
                    : {}),
            },
        });

        res.json((meetings || []).map((m) => ({ ...m, files: m.files || [] })));
    } catch (error) {
        logger.error('GET_MEETINGS', 'Erreur récupération réunions', {
            userId: req.user.id,
            error: error.message,
        });
        res.status(400).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/meetings/{id}:
 *   get:
 *     summary: Récupérer le détail d'une réunion
 *     tags: [Meetings]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Détail de la réunion
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 */
router.get('/:id', async (req, res) => {
    try {
        const includeFiles = await canUseMeetingFiles(req.prisma);
        const meeting = await req.prisma.meeting.findUnique({
            where: { id: req.params.id },
            include: {
                organizer: true,
                room: true,
                invitations: { include: { user: true } },
                messages: {
                    include: {
                        sender: { select: { id: true, name: true, email: true, avatarUrl: true } },
                        parent: {
                            select: {
                                id: true,
                                body: true,
                                sender: { select: { id: true, name: true } },
                            },
                        },
                    },
                    orderBy: { createdAt: 'asc' },
                },
                ...(includeFiles
                    ? {
                          files: {
                              include: { uploadedBy: { select: { id: true, name: true, email: true } } },
                              orderBy: { createdAt: 'desc' },
                          },
                      }
                    : {}),
            },
        });

        if (!meeting) {
            return res.status(404).json({ error: 'Meeting not found' });
        }

        if (!canViewMeeting(meeting, req.user)) {
            return res.status(403).json({ error: 'Accès non autorisé' });
        }

        res.json({ ...meeting, files: meeting.files || [], messages: meeting.messages || [] });
    } catch (error) {
        logger.error('GET_MEETING', 'Erreur récupération réunion', {
            meetingId: req.params.id,
            error: error.message,
        });
        res.status(400).json({ error: error.message });
    }
});

// POST /api/meetings/:id/messages - envoyer un message dans la réunion
router.post('/:id/messages', async (req, res) => {
    try {
        const body = String(req.body?.body || '').trim();
        const parentId = req.body?.parentId || null;
        if (!body) {
            return res.status(400).json({ error: 'Le message ne peut pas être vide.' });
        }
        if (body.length > 3000) {
            return res.status(400).json({ error: 'Le message est trop long (3000 caractères max).' });
        }

        const meeting = await req.prisma.meeting.findUnique({
            where: { id: req.params.id },
            include: { invitations: true },
        });
        if (!meeting) return res.status(404).json({ error: 'Réunion introuvable' });
        if (!isParticipant(meeting, req.user)) {
            return res.status(403).json({ error: 'Seuls les participants peuvent envoyer des messages.' });
        }
        if (meeting.status === 'CANCELLED') {
            return res.status(400).json({ error: 'Impossible d\'envoyer un message sur une réunion annulée.' });
        }

        if (parentId) {
            const parentMsg = await req.prisma.meetingMessage.findUnique({ where: { id: parentId } });
            if (!parentMsg || parentMsg.meetingId !== meeting.id) {
                return res.status(400).json({ error: 'Message parent invalide.' });
            }
        }

        const created = await req.prisma.meetingMessage.create({
            data: {
                meetingId: meeting.id,
                senderId: req.user.id,
                body,
                parentId,
            },
            include: {
                sender: { select: { id: true, name: true, email: true, avatarUrl: true } },
                parent: {
                    select: {
                        id: true,
                        body: true,
                        sender: { select: { id: true, name: true } },
                    },
                },
            },
        });

        res.status(201).json(created);
    } catch (error) {
        logger.error('MEETING_MESSAGE_CREATE', error.message, { meetingId: req.params.id, userId: req.user?.id });
        res.status(400).json({ error: error.message });
    }
});

// POST /api/meetings/:id/files - ajouter un fichier (image, document, compte rendu)
router.post('/:id/files', uploadMeetingFile.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'Aucun fichier envoyé. Utilisez le champ "file".' });
        }

        const meeting = await req.prisma.meeting.findUnique({
            where: { id: req.params.id },
            include: { invitations: true },
        });
        if (!meeting) return res.status(404).json({ error: 'Réunion introuvable' });
        if (!isParticipant(meeting, req.user)) {
            return res.status(403).json({ error: 'Seuls les participants peuvent ajouter des fichiers.' });
        }

        const rawKind = String(req.body?.kind || 'DOCUMENT').toUpperCase();
        const allowedKinds = ['IMAGE', 'DOCUMENT', 'REPORT'];
        const kind = allowedKinds.includes(rawKind) ? rawKind : 'DOCUMENT';
        const fileUrl = `/uploads/meetings/${req.file.filename}`;

        const saved = await req.prisma.meetingFile.create({
            data: {
                meetingId: meeting.id,
                uploadedById: req.user.id,
                kind,
                fileName: req.file.originalname || req.file.filename,
                fileUrl,
                mimeType: req.file.mimetype || null,
                size: req.file.size || null,
            },
            include: { uploadedBy: { select: { id: true, name: true, email: true } } },
        });

        await createAuditLog(req, 'MEETING_FILE_ADDED', 'MeetingFile', saved.id, `Fichier "${saved.fileName}" ajouté (${kind})`);
        res.status(201).json(saved);
    } catch (error) {
        logger.error('MEETING_FILE_ADD', error.message, { meetingId: req.params.id });
        res.status(400).json({ error: error.message });
    }
});

// DELETE /api/meetings/:id/files/:fileId - suppression par l'auteur uniquement
router.delete('/:id/files/:fileId', async (req, res) => {
    try {
        const file = await req.prisma.meetingFile.findUnique({
            where: { id: req.params.fileId },
            include: { meeting: { include: { invitations: true } } },
        });
        if (!file || file.meetingId !== req.params.id) {
            return res.status(404).json({ error: 'Fichier introuvable' });
        }
        if (!isParticipant(file.meeting, req.user)) {
            return res.status(403).json({ error: 'Accès non autorisé' });
        }
        if (file.uploadedById !== req.user.id) {
            return res.status(403).json({ error: 'Seul l\'utilisateur ayant ajouté ce fichier peut le supprimer.' });
        }

        await req.prisma.meetingFile.delete({ where: { id: file.id } });
        const localPath = path.join(meetingsUploadDir, path.basename(file.fileUrl || ''));
        try {
            if (localPath && fs.existsSync(localPath)) fs.unlinkSync(localPath);
        } catch {}

        await createAuditLog(req, 'MEETING_FILE_DELETED', 'MeetingFile', file.id, `Fichier "${file.fileName}" supprimé`);
        res.json({ success: true });
    } catch (error) {
        logger.error('MEETING_FILE_DELETE', error.message, { meetingId: req.params.id, fileId: req.params.fileId });
        res.status(400).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/meetings/{id}/attachment:
 *   post:
 *     summary: Joindre un fichier à la réunion (organisateur ou admin)
 *     tags: [Meetings]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       content:
 *         multipart/form-data:
 *           schema:
 *             properties:
 *               file:
 *                 type: string
 *                 format: binary
 *     responses:
 *       200:
 *         description: Fichier joint (attachmentUrl dans la réponse)
 *       403:
 *         description: Non autorisé
 */
router.post('/:id/attachment', uploadMeetingFile.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'Aucun fichier envoyé. Utilisez le champ "file".' });
        }
        const meeting = await req.prisma.meeting.findUnique({ where: { id: req.params.id } });
        if (!meeting) return res.status(404).json({ error: 'Réunion introuvable' });
        const isOrganizer = meeting.organizerId === req.user.id;
        const isAdmin = req.user.role === ROLES.ADMIN;
        if (!isOrganizer && !isAdmin) {
            return res.status(403).json({ error: 'Seul l\'organisateur ou un administrateur peut joindre un fichier.' });
        }
        const attachmentUrl = `/uploads/meetings/${req.file.filename}`;
        await req.prisma.meeting.update({
            where: { id: req.params.id },
            data: { attachments: attachmentUrl },
        });
        res.json({ attachmentUrl });
    } catch (error) {
        logger.error('MEETING_ATTACHMENT', error.message, { meetingId: req.params.id });
        res.status(400).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/meetings/{id}:
 *   put:
 *     summary: Modifier une réunion (organisateur). En cas de changement d'horaire/salle, envoi d'un email aux invités.
 *     tags: [Meetings]
 *     security:
 *       - bearerAuth: []
 */
router.put('/:id', async (req, res) => {
    try {
        const meeting = await req.prisma.meeting.findUnique({
            where: { id: req.params.id },
            include: {
                invitations: { include: { user: true } },
                room: true,
            },
        });

        if (!meeting) {
            return res.status(404).json({ error: 'Réunion introuvable' });
        }

        if (meeting.organizerId !== req.user.id) {
            return res.status(403).json({ error: 'Seul l\'organisateur peut modifier cette réunion' });
        }

        const { title, agenda, roomId, meetingLink, startTime, endTime } = req.body;
        const newStart = startTime ? new Date(startTime) : meeting.startTime;
        const newEnd = endTime ? new Date(endTime) : meeting.endTime;
        const hasMeetingLinkInPayload = meetingLink !== undefined;
        const normalizedMeetingLink = hasMeetingLinkInPayload ? normalizeMeetingLink(meetingLink) : meeting.meetingLink;

        if (newStart >= newEnd) {
            return res.status(400).json({ error: 'L\'heure de fin doit être après l\'heure de début' });
        }

        const timeOrRoomChanged =
            newStart.getTime() !== new Date(meeting.startTime).getTime() ||
            newEnd.getTime() !== new Date(meeting.endTime).getTime() ||
            String(roomId || '') !== String(meeting.roomId || '');

        const newRoomId = roomId !== undefined ? (roomId || null) : meeting.roomId;
        if (!newRoomId && !normalizedMeetingLink) {
            return res.status(400).json({ error: 'Renseignez une salle ou un lien de visioconférence.' });
        }
        if (hasMeetingLinkInPayload && String(meetingLink || '').trim() && !normalizedMeetingLink) {
            return res.status(400).json({ error: 'Lien de visioconférence invalide (http/https requis).' });
        }

        if (newRoomId) {
            const active = await isRoomActive(req.prisma, newRoomId);
            if (!active) {
                return res.status(410).json({
                    error: 'Cette salle est désactivée. Choisissez une autre salle active.',
                });
            }
        }

        if (newRoomId) {
            const available = await isRoomAvailableForSlot(
                req.prisma,
                newRoomId,
                newStart,
                newEnd,
                meeting.id
            );
            if (!available) {
                return res.status(409).json({
                    error: 'Cette salle n\'est pas libre sur le créneau choisi.',
                });
            }
        }

        const updated = await req.prisma.meeting.update({
            where: { id: req.params.id },
            data: {
                ...(title !== undefined && { title }),
                ...(agenda !== undefined && { agenda }),
                ...(roomId !== undefined && { roomId: newRoomId }),
                ...(hasMeetingLinkInPayload && { meetingLink: normalizedMeetingLink }),
                ...(startTime !== undefined && { startTime: newStart }),
                ...(endTime !== undefined && { endTime: newEnd }),
            },
            include: {
                organizer: { select: { name: true, email: true } },
                room: true,
                invitations: { include: { user: true } },
            },
        });

        const existingBooking = await req.prisma.roomBooking.findUnique({
            where: { meetingId: meeting.id },
        });

        if (meeting.status === 'SENT' && (existingBooking || newRoomId)) {
            const dateForBooking = new Date(updated.startTime);
            const startStr = updated.startTime.toLocaleTimeString('fr-FR', {
                hour: '2-digit',
                minute: '2-digit',
            });
            const endStr = updated.endTime.toLocaleTimeString('fr-FR', {
                hour: '2-digit',
                minute: '2-digit',
            });

            if (existingBooking) {
                await req.prisma.roomBooking.updateMany({
                    where: { meetingId: meeting.id },
                    data: {
                        roomId: newRoomId || existingBooking.roomId,
                        date: dateForBooking,
                        startTime: startStr,
                        endTime: endStr,
                    },
                });
            } else if (newRoomId) {
                await req.prisma.roomBooking.create({
                    data: {
                        roomId: newRoomId,
                        meetingId: meeting.id,
                        userId: req.user.id,
                        date: dateForBooking,
                        startTime: startStr,
                        endTime: endStr,
                    },
                });
            }
        }

        if (timeOrRoomChanged && meeting.status === 'SENT' && meeting.invitations?.length > 0) {
            for (const inv of meeting.invitations) {
                await notificationService.sendFullNotification(
                    req.prisma,
                    inv.user.id,
                    inv.user.email,
                    'MEETING_SCHEDULE_UPDATED',
                    'MEETING_SCHEDULE_UPDATED',
                    [inv.user, updated, updated.room],
                    `Modification : ${updated.title}`,
                    `L'horaire ou le lieu de la réunion "${updated.title}" a été modifié.`,
                    `/meetings/${updated.id}`
                );
            }
        }

        await createAuditLog(
            req,
            'MEETING_UPDATED',
            'Meeting',
            req.params.id,
            `Réunion "${updated.title}" modifiée` + (timeOrRoomChanged ? ' (horaire/salle)' : '')
        );

        res.json(updated);
    } catch (error) {
        logger.error('UPDATE_MEETING', 'Erreur modification réunion', {
            meetingId: req.params.id,
            error: error.message,
        });
        res.status(400).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/meetings:
 *   post:
 *     summary: Créer une nouvelle réunion
 *     tags: [Meetings]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [title, agenda, startTime, endTime, participants]
 *             properties:
 *               title:
 *                 type: string
 *                 example: Réunion de direction
 *               agenda:
 *                 type: string
 *                 example: Point mensuel sur les projets
 *               roomId:
 *                 type: string
 *                 nullable: true
 *               startTime:
 *                 type: string
 *                 format: date-time
 *               endTime:
 *                 type: string
 *                 format: date-time
 *               participants:
 *                 type: array
 *                 items:
 *                   type: string
 *                 description: Liste des IDs des participants
 *     responses:
 *       200:
 *         description: Réunion créée
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Meeting'
 *       409:
 *         description: Conflit de réservation de salle
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 */
router.post('/', async (req, res) => {
    try {
        const { title, agenda, roomId, meetingLink, startTime, endTime, participants, participantIds } = req.body;
        const participantListRaw = Array.isArray(participants)
            ? participants
            : Array.isArray(participantIds)
              ? participantIds
              : [];
        const participantList = [...new Set(participantListRaw.filter(Boolean))];
        const normalizedMeetingLink = normalizeMeetingLink(meetingLink);

        const start = new Date(startTime);
        const end = new Date(endTime);
        if (start >= end) {
            return res.status(400).json({ error: 'L\'heure de fin doit être après l\'heure de début' });
        }
        if (!roomId && !normalizedMeetingLink) {
            return res.status(400).json({ error: 'Renseignez une salle ou un lien de visioconférence.' });
        }
        if (String(meetingLink || '').trim() && !normalizedMeetingLink) {
            return res.status(400).json({ error: 'Lien de visioconférence invalide (http/https requis).' });
        }

        // Vérifier conflits participants : réunions et missions
        for (const uid of participantList) {
            if (uid === req.user.id) continue;
            const [meetingConflict, missionConflict] = await Promise.all([
                getUserMeetingConflict(req.prisma, uid, start, end),
                getUserMissionConflictForMeeting(req.prisma, uid, start, end),
            ]);
            if (meetingConflict) {
                return res.status(409).json({
                    error: `Conflit participant: cet utilisateur a déjà une réunion sur ce créneau (${meetingConflict.title}).`,
                    userId: uid,
                    conflictType: 'MEETING',
                    conflictId: meetingConflict.id,
                });
            }
            if (missionConflict) {
                return res.status(409).json({
                    error: `Conflit participant: cet utilisateur a déjà une mission sur ce créneau (${missionConflict.title}).`,
                    userId: uid,
                    conflictType: 'MISSION',
                    conflictId: missionConflict.id,
                });
            }
        }

        // Réunion sur une salle libre : salle doit être ACTIVE
        if (roomId) {
            const active = await isRoomActive(req.prisma, roomId);
            if (!active) {
                return res.status(410).json({
                    error: 'Cette salle est désactivée. Aucune réunion ne peut y être planifiée tant qu\'elle n\'est pas réactivée.',
                });
            }
        }

        // Réunion sur une salle libre : vérifier que le créneau est libre
        if (roomId) {
            const available = await isRoomAvailableForSlot(req.prisma, roomId, start, end);
            if (!available) {
                return res.status(409).json({
                    error: 'Cette salle n\'est pas libre sur le créneau choisi. Choisissez une autre salle ou un autre horaire.',
                });
            }
        }

        const meeting = await req.prisma.meeting.create({
            data: {
                title,
                agenda: agenda || '',
                organizerId: req.user.id,
                roomId: roomId || null,
                meetingLink: normalizedMeetingLink,
                startTime: start,
                endTime: end,
                status: 'DRAFT',
                invitations: {
                    create: participantList.map((userId) => ({ userId, status: 'PENDING' })),
                },
            },
            include: { invitations: true },
        });

        logger.info('MEETING_CREATED', `Réunion créée par ${req.user.name}`, {
            meetingId: meeting.id,
            organizerId: req.user.id,
            title,
        });

        await createAuditLog(req, 'MEETING_CREATED', 'Meeting', meeting.id, `Réunion "${title}" créée`);

        res.json(meeting);
    } catch (error) {
        logger.error('CREATE_MEETING', 'Erreur création réunion', {
            userId: req.user.id,
            error: error.message,
        });
        res.status(400).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/meetings/{id}/send:
 *   put:
 *     summary: Envoyer les convocations aux participants
 *     tags: [Meetings]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Convocations envoyées avec succès
 *       403:
 *         description: Non autorisé (seul l'organisateur peut envoyer)
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 */
router.put('/:id/send', async (req, res) => {
    try {
        const meeting = await req.prisma.meeting.findUnique({
            where: { id: req.params.id },
            include: {
                invitations: { include: { user: true } },
                room: true,
            },
        });

        if (meeting.organizerId !== req.user.id) {
            return res.status(403).json({ error: 'Not authorized' });
        }

        if (meeting.roomId) {
            const active = await isRoomActive(req.prisma, meeting.roomId);
            if (!active) {
                return res.status(410).json({
                    error: 'La salle de cette réunion est désactivée. Réactivez la salle ou choisissez une autre salle avant d\'envoyer.',
                });
            }
        }

        // Vérifier à nouveau que le créneau est libre avant de réserver (au cas où une autre réunion aurait été envoyée entretemps)
        // meetingId est unique sur RoomBooking : upsert pour ré-envoi ou mise à jour sans doublon
        if (meeting.roomId) {
            const available = await isRoomAvailableForSlot(
                req.prisma,
                meeting.roomId,
                meeting.startTime,
                meeting.endTime,
                meeting.id
            );
            if (!available) {
                return res.status(409).json({
                    error: 'La salle n\'est plus disponible sur ce créneau. Choisissez un autre horaire ou une autre salle.',
                });
            }
            const dateForBooking = new Date(meeting.startTime);
            const startStr = meeting.startTime.toLocaleTimeString('fr-FR', {
                hour: '2-digit',
                minute: '2-digit',
            });
            const endStr = meeting.endTime.toLocaleTimeString('fr-FR', {
                hour: '2-digit',
                minute: '2-digit',
            });

            const existingBooking = await req.prisma.roomBooking.findUnique({
                where: { meetingId: meeting.id },
            });
            if (existingBooking) {
                await req.prisma.roomBooking.update({
                    where: { id: existingBooking.id },
                    data: {
                        roomId: meeting.roomId,
                        userId: req.user.id,
                        date: dateForBooking,
                        startTime: startStr,
                        endTime: endStr,
                        status: 'CONFIRMED',
                    },
                });
            } else {
                await req.prisma.roomBooking.create({
                    data: {
                        roomId: meeting.roomId,
                        meetingId: meeting.id,
                        userId: req.user.id,
                        date: dateForBooking,
                        startTime: startStr,
                        endTime: endStr,
                    },
                });
            }
        }

        // Send email + in-app notification to each participant
        for (const inv of meeting.invitations) {
            await notificationService.sendFullNotification(
                req.prisma,
                inv.user.id,
                inv.user.email,
                'MEETING_CONVOCATION',
                'MEETING_CONVOCATION',
                [inv.user, meeting, meeting.room],
                `Convocation : ${meeting.title}`,
                `Vous êtes convoqué(e) le ${new Date(meeting.startTime).toLocaleDateString('fr-FR')}`,
                `/meetings`
            );
        }

        const updated = await req.prisma.meeting.update({
            where: { id: req.params.id },
            data: {
                status: 'SENT',
                invitations: {
                    updateMany: { where: {}, data: { sentAt: new Date() } },
                },
            },
        });

        logger.info('MEETING_SENT', `Convocations envoyées pour "${meeting.title}"`, {
            meetingId: req.params.id,
            organizerId: req.user.id,
            participantCount: meeting.invitations.length,
        });

        await createAuditLog(req, 'MEETING_SENT', 'Meeting', req.params.id, `Convocations réunion "${meeting.title}" envoyées`);

        res.json(updated);
    } catch (error) {
        logger.error('SEND_MEETING', 'Erreur envoi convocations', {
            meetingId: req.params.id,
            error: error.message,
        });
        res.status(400).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/meetings/{id}/cancel:
 *   put:
 *     summary: Annuler une réunion
 *     tags: [Meetings]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Réunion annulée
 *       403:
 *         description: Non autorisé
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 */
router.put('/:id/cancel', async (req, res) => {
    try {
        const meeting = await req.prisma.meeting.findUnique({
            where: { id: req.params.id },
            include: { invitations: { include: { user: true } } },
        });

        if (meeting.organizerId !== req.user.id) {
            return res.status(403).json({ error: 'Not authorized' });
        }

        const updated = await req.prisma.meeting.update({
            where: { id: req.params.id },
            data: { status: 'CANCELLED' },
        });

        await req.prisma.roomBooking.updateMany({
            where: { meetingId: req.params.id },
            data: { status: 'CANCELLED' },
        });

        // Notify all participants
        const participantIds = meeting.invitations.map((inv) => inv.userId);
        if (participantIds.length > 0) {
            await notificationService.sendBulkNotification(
                req.prisma,
                participantIds,
                'MEETING_CANCELLED',
                `Réunion annulée : ${meeting.title}`,
                `La réunion du ${new Date(meeting.startTime).toLocaleDateString('fr-FR')} a été annulée`,
                `/meetings`
            );
        }

        logger.info('MEETING_CANCELLED', `Réunion "${meeting.title}" annulée`, {
            meetingId: req.params.id,
            organizerId: req.user.id,
        });

        await createAuditLog(req, 'MEETING_CANCELLED', 'Meeting', req.params.id, `Réunion "${meeting.title}" annulée`);

        res.json(updated);
    } catch (error) {
        logger.error('CANCEL_MEETING', 'Erreur annulation réunion', {
            meetingId: req.params.id,
            error: error.message,
        });
        res.status(400).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/meetings/invitations/{id}/respond:
 *   post:
 *     summary: Répondre à une invitation (accepter/décliner)
 *     tags: [Meetings]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID de l'invitation
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [status]
 *             properties:
 *               status:
 *                 type: string
 *                 enum: [ACCEPTED, DECLINED]
 *     responses:
 *       200:
 *         description: Réponse enregistrée
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 */
router.post('/invitations/:id/respond', async (req, res) => {
    try {
        const { status } = req.body;

        const updated = await req.prisma.invitation.update({
            where: { id: req.params.id },
            data: { status, respondedAt: new Date() },
            include: { meeting: { include: { organizer: true } } },
        });

        logger.info('INVITATION_RESPONDED', `Invitation ${req.params.id} - réponse: ${status}`, {
            invitationId: req.params.id,
            userId: req.user.id,
            status,
        });

        // Notify organizer of the response
        await notificationService.createNotification(
            req.prisma,
            updated.meeting.organizerId,
            'MEETING_CONVOCATION',
            `Réponse de ${req.user.name}`,
            `${req.user.name} a ${status === 'ACCEPTED' ? 'accepté' : 'décliné'} votre réunion "${updated.meeting.title}"`,
            `/meetings`
        );

        res.json(updated);
    } catch (error) {
        logger.error('RESPOND_INVITATION', 'Erreur réponse invitation', {
            invitationId: req.params.id,
            error: error.message,
        });
        res.status(400).json({ error: error.message });
    }
});

/**
 * @swagger
 * /api/meetings/{id}/participants:
 *   post:
 *     summary: Ajouter des participants à une réunion existante
 *     tags: [Meetings]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [userIds]
 *             properties:
 *               userIds:
 *                 type: array
 *                 items:
 *                   type: string
 *                 description: Liste des IDs des utilisateurs à ajouter
 *     responses:
 *       200:
 *         description: Participants ajoutés
 */
router.post('/:id/participants', async (req, res) => {
    try {
        const { userIds } = req.body || {};
        if (!Array.isArray(userIds) || userIds.length === 0) {
            return res.status(400).json({ error: 'Liste userIds requise' });
        }

        const meeting = await req.prisma.meeting.findUnique({
            where: { id: req.params.id },
            include: {
                invitations: true,
                room: true,
            },
        });

        if (!meeting) {
            return res.status(404).json({ error: 'Réunion introuvable' });
        }

        if (meeting.organizerId !== req.user.id && req.user.role !== 'ADMIN') {
            return res.status(403).json({ error: 'Seul l\'organisateur ou un admin peut ajouter des participants' });
        }

        if (meeting.status === 'CANCELLED') {
            return res.status(400).json({ error: 'Impossible d\'ajouter des participants à une réunion annulée' });
        }

        const existingIds = new Set(meeting.invitations.map((inv) => inv.userId));
        const toAdd = userIds.filter((uid) => uid && !existingIds.has(uid) && uid !== meeting.organizerId);

        if (toAdd.length === 0) {
            return res.status(400).json({ error: 'Aucun nouveau participant à ajouter' });
        }

        // Vérifier conflits avant ajout (réunion + mission)
        for (const uid of toAdd) {
            const [meetingConflict, missionConflict] = await Promise.all([
                getUserMeetingConflict(req.prisma, uid, meeting.startTime, meeting.endTime, meeting.id),
                getUserMissionConflictForMeeting(req.prisma, uid, meeting.startTime, meeting.endTime),
            ]);
            if (meetingConflict) {
                return res.status(409).json({
                    error: `Conflit participant: cet utilisateur a déjà une réunion sur ce créneau (${meetingConflict.title}).`,
                    userId: uid,
                    conflictType: 'MEETING',
                    conflictId: meetingConflict.id,
                });
            }
            if (missionConflict) {
                return res.status(409).json({
                    error: `Conflit participant: cet utilisateur a déjà une mission sur ce créneau (${missionConflict.title}).`,
                    userId: uid,
                    conflictType: 'MISSION',
                    conflictId: missionConflict.id,
                });
            }
        }

        await req.prisma.invitation.createMany({
            data: toAdd.map((uid) => ({
                meetingId: meeting.id,
                userId: uid,
                status: 'PENDING',
            })),
        });

        // Si la réunion est déjà envoyée, notifier immédiatement les nouveaux participants
        if (meeting.status === 'SENT') {
            const newUsers = await req.prisma.user.findMany({
                where: { id: { in: toAdd } },
            });

            for (const u of newUsers) {
                await notificationService.sendFullNotification(
                    req.prisma,
                    u.id,
                    u.email,
                    'MEETING_CONVOCATION',
                    'MEETING_CONVOCATION',
                    [u, meeting, meeting.room],
                    `Convocation : ${meeting.title}`,
                    `Vous êtes convoqué(e) le ${new Date(meeting.startTime).toLocaleDateString('fr-FR')}`,
                    `/meetings`
                );
            }
        }

        await createAuditLog(req, 'MEETING_PARTICIPANTS_ADDED', 'Meeting', meeting.id, `${toAdd.length} participant(s) ajouté(s)`);

        res.json({ success: true, added: toAdd.length });
    } catch (error) {
        logger.error('ADD_MEETING_PARTICIPANTS', 'Erreur ajout participants', {
            meetingId: req.params.id,
            error: error.message,
        });
        res.status(400).json({ error: error.message });
    }
});

module.exports = router;
