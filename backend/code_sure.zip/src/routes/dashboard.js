const express = require('express');
const roleMiddleware = require('../middlewares/role.middleware');
const { ROLES } = require('../config/roles');

const router = express.Router();

// GET /api/dashboard/admin-stats — Statistiques globales enrichies (ADMIN uniquement) — CDC §3.7.3
router.get('/admin-stats', roleMiddleware([ROLES.ADMIN]), async (req, res) => {
    try {
        if (!req.prisma) {
            return res.status(200).json({ users: 0, activeUsers: 0, inactiveUsers: 0, usersByRole: {}, plannings: 0, planningsByStatus: {}, validationRate: 0, pendingPlannings: 0, missions: 0, activeMissions: 0, meetings: 0, meetingsThisMonth: 0, rooms: 0, roomOccupancy7d: 0 });
        }

        const now = new Date();
        const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
        const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
        const sevenDaysAgo = new Date(now);
        sevenDaysAgo.setDate(now.getDate() - 6);
        sevenDaysAgo.setHours(0, 0, 0, 0);

        const [
            allUsers,
            planningsByStatus,
            missionsCount,
            activeMissionsCount,
            meetingsCount,
            meetingsThisMonth,
            roomsCount,
            roomsWithBookings,
            usersByRole,
        ] = await Promise.all([
            req.prisma.user.findMany({
                where: { isDeleted: false },
                select: { isActive: true, role: true },
            }),
            req.prisma.planning.groupBy({ by: ['status'], _count: { id: true } }),
            req.prisma.mission.count({ where: { status: { not: 'CANCELLED' } } }),
            req.prisma.mission.count({ where: { status: 'CONFIRMED', startTime: { lte: now }, endTime: { gte: now } } }),
            req.prisma.meeting.count({ where: { status: { not: 'CANCELLED' } } }),
            req.prisma.meeting.count({ where: { status: { not: 'CANCELLED' }, startTime: { gte: monthStart, lte: monthEnd } } }),
            req.prisma.room.count({ where: { status: 'ACTIVE' } }),
            // Réservations confirmées sur les 7 derniers jours
            req.prisma.roomBooking.findMany({
                where: { status: 'CONFIRMED', date: { gte: sevenDaysAgo, lte: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999) } },
                select: { startTime: true, endTime: true },
            }),
            req.prisma.user.groupBy({ by: ['role'], _count: { id: true }, where: { isDeleted: false } }),
        ]);

        // Statistiques utilisateurs
        const activeUsers = allUsers.filter((u) => u.isActive).length;
        const inactiveUsers = allUsers.length - activeUsers;
        const roleStats = {};
        (usersByRole || []).forEach((x) => { roleStats[x.role] = x._count?.id ?? 0; });

        // Statistiques plannings
        const planningsTotal = (planningsByStatus || []).reduce((s, x) => s + (x._count?.id ?? 0), 0);
        const planningsMap = {};
        (planningsByStatus || []).forEach((x) => { planningsMap[x.status] = x._count?.id ?? 0; });
        const pendingPlannings = (planningsMap['SUBMITTED'] || 0) + (planningsMap['IN_CONSOLIDATION'] || 0);
        // Taux de validation CDC §3.7.3: VALIDATED / (tout sauf DRAFT) * 100
        const nonDraftTotal = planningsTotal - (planningsMap['DRAFT'] || 0);
        const validationRate = nonDraftTotal > 0
            ? Math.round(((planningsMap['VALIDATED'] || 0) / nonDraftTotal) * 100)
            : 0;

        // Taux d'occupation salles 7 jours — CDC §3.7.3
        // Formule: somme durées réservations / (nb salles * 8h * 7j) * 100
        const totalSlotMinutes = roomsCount * 8 * 60 * 7; // 8h par jour * 7 jours
        let bookedMinutes = 0;
        (roomsWithBookings || []).forEach((b) => {
            const [sh, sm] = b.startTime.split(':').map(Number);
            const [eh, em] = b.endTime.split(':').map(Number);
            bookedMinutes += Math.max(0, (eh * 60 + em) - (sh * 60 + sm));
        });
        const roomOccupancy7d = totalSlotMinutes > 0
            ? Math.round((bookedMinutes / totalSlotMinutes) * 100)
            : 0;

        res.status(200).json({
            // Utilisateurs
            users: allUsers.length,
            activeUsers,
            inactiveUsers,
            usersByRole: roleStats,
            // Plannings
            plannings: planningsTotal,
            planningsByStatus: planningsMap,
            pendingPlannings,
            validationRate,
            // Missions
            missions: missionsCount,
            activeMissions: activeMissionsCount,
            // Réunions
            meetings: meetingsCount,
            meetingsThisMonth,
            // Salles
            rooms: roomsCount,
            roomOccupancy7d,
        });
    } catch (error) {
        console.error('Dashboard admin-stats error:', error);
        res.status(500).json({ error: error.message });
    }
});

function startOfDay(d) {
    const x = new Date(d);
    x.setHours(0, 0, 0, 0);
    return x;
}

function endOfDay(d) {
    const x = new Date(d);
    x.setHours(23, 59, 59, 999);
    return x;
}

// GET /api/dashboard/today - Dashboard for today (salles occupées / libres)
router.get('/today', async (req, res) => {
    const emptyPayload = {
        freeRooms: 0,
        occupiedRooms: 0,
        meetingsToday: 0,
        pendingPlannings: 0,
        rooms: [],
    };
    try {
        if (!req.prisma) {
            return res.status(200).json(emptyPayload);
        }
        const todayStart = startOfDay(new Date());
        const todayEnd = endOfDay(new Date());

        const rooms = await req.prisma.room.findMany({
            where: { status: 'ACTIVE' },
            include: {
                bookings: {
                    where: {
                        status: 'CONFIRMED',
                        date: {
                            gte: todayStart,
                            lte: todayEnd,
                        },
                    },
                    include: { meeting: { select: { id: true, title: true } } },
                    orderBy: { createdAt: 'desc' },
                },
            },
        });

        const meetingsToday = await req.prisma.meeting.count({
            where: {
                status: { not: 'CANCELLED' },
                startTime: { gte: todayStart, lte: todayEnd },
            },
        });

        const pendingPlannings = await req.prisma.planning.count({
            where: {
                status: { in: ['SUBMITTED', 'IN_CONSOLIDATION'] },
            },
        });

        const roomsWithStatus = (rooms || []).map((r) => {
            const bookingsList = (r.bookings || []).map((b) => ({
                id: b.id,
                startTime: b.startTime,
                endTime: b.endTime,
                meetingTitle: (b.meeting && b.meeting.title) || null,
                meetingId: b.meetingId,
            }));
            const occupied = bookingsList.length > 0;
            return {
                id: r.id,
                name: r.name,
                capacity: r.capacity,
                location: r.location || '',
                status: occupied ? 'OCCUPIED' : 'FREE',
                bookings: bookingsList,
                booking: bookingsList[0] || null,
            };
        });

        const occupiedRooms = roomsWithStatus.filter((r) => r.status === 'OCCUPIED').length;
        const freeRooms = roomsWithStatus.length - occupiedRooms;

        res.status(200).json({
            freeRooms,
            occupiedRooms,
            meetingsToday,
            pendingPlannings,
            rooms: roomsWithStatus,
        });
    } catch (error) {
        console.error('Dashboard today error:', error);
        res.status(200).json(emptyPayload);
    }
});

// GET /api/dashboard/week - Occupation sur la semaine
router.get('/week', async (req, res) => {
    const emptyPayload = {
        occupancyRate: '0',
        bookedSlots: 0,
        submittedPlannings: 0,
        weekStart: new Date().toISOString(),
        weekEnd: new Date().toISOString(),
        rooms: [],
    };
    try {
        if (!req.prisma) {
            return res.status(200).json(emptyPayload);
        }
        const now = new Date();
        const weekStart = startOfDay(new Date(now));
        weekStart.setDate(now.getDate() - ((now.getDay() + 6) % 7)); // Monday
        const weekEnd = endOfDay(new Date(weekStart));
        weekEnd.setDate(weekStart.getDate() + 6);

        const rooms = await req.prisma.room.findMany({
            where: { status: 'ACTIVE' },
            include: {
                bookings: {
                    where: {
                        status: 'CONFIRMED',
                        date: { gte: weekStart, lte: weekEnd },
                    },
                },
            },
        });

        const totalSlots = (rooms && rooms.length) ? rooms.length * 7 * 11 : 0;
        const bookedCount = (rooms || []).reduce((sum, room) => sum + (room.bookings ? room.bookings.length : 0), 0);

        const [submittedPlannings, activeMissions] = await Promise.all([
            req.prisma.planning.count({
                where: {
                    status: 'VALIDATED',
                    weekStart: { gte: weekStart, lte: weekEnd },
                },
            }),
            // Missions actives chevauchant la semaine — CDC §3.7.2
            req.prisma.mission.count({
                where: {
                    status: 'CONFIRMED',
                    startTime: { lte: weekEnd },
                    endTime: { gte: weekStart },
                },
            }),
        ]);

        res.status(200).json({
            occupancyRate:
                totalSlots > 0 ? ((bookedCount / totalSlots) * 100).toFixed(1) : '0',
            bookedSlots: bookedCount,
            submittedPlannings,
            activeMissions,
            weekStart: weekStart.toISOString(),
            weekEnd: weekEnd.toISOString(),
            rooms: (rooms || []).map((r) => ({
                id: r.id,
                name: r.name,
                bookingsCount: r.bookings ? r.bookings.length : 0,
            })),
        });
    } catch (error) {
        console.error('Dashboard week error:', error);
        res.status(200).json(emptyPayload);
    }
});

module.exports = router;
