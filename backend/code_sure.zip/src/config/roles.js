const ROLES = {
    RESPONSABLE: 'RESPONSABLE',
    CONSOLIDATEUR: 'CONSOLIDATEUR',
    DG: 'DG',
    ADMIN: 'ADMIN',
};

const ALL_ROLES = Object.values(ROLES);

function isValidRole(role) {
    return ALL_ROLES.includes(role);
}

module.exports = {
    ROLES,
    ALL_ROLES,
    isValidRole,
};


