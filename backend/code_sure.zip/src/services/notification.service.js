const nodemailer = require('nodemailer');
const { logger } = require('../utils/logger');

// Configuration de l'email
const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'localhost',
    port: parseInt(process.env.SMTP_PORT || '1025'),
    auth: process.env.SMTP_USER ?
        {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
        } :
        undefined,
    secure: process.env.SMTP_SECURE === 'true',
    tls: {
        rejectUnauthorized: false,
    },
});

// Templates d'emails
const emailTemplates = {
    PLANNING_REMINDER: (user) => ({
        subject: '📋 Rappel : Soumettez votre planning hebdomadaire',
        html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>C'est un rappel amical pour vous informer qu'il est temps de soumettre votre planning hebdomadaire.</p>
          <div style="background: #f0f0f0; padding: 15px; border-left: 4px solid #1F5C8B; margin: 20px 0;">
            <strong>⏰ Deadline: Vendredi 12h00</strong>
          </div>
          <p>
            <a href="${process.env.FRONTEND_URL}/planning" style="display: inline-block; background: #1F5C8B; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
              Soumettre mon planning
            </a>
          </p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
    }),

    PLANNING_SUBMITTED: (user, planningId) => ({
        subject: '✅ Confirmation : Votre planning a été reçu',
        html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>✅ Votre planning a été soumis avec succès!</p>
          <div style="background: #e8f5e9; padding: 15px; border-left: 4px solid #4caf50; margin: 20px 0;">
            <strong>Status:</strong> Planning reçu et en cours de consolidation
          </div>
          <p>Le consolidateur examinera votre planning et le transmettra au Directeur Général pour validation.</p>
          <p>
            <a href="${process.env.FRONTEND_URL}/planning" style="display: inline-block; background: #1F5C8B; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
              Consulter mon planning
            </a>
          </p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
    }),

    PLANNING_VALIDATED: (user) => ({
        subject: '🎉 Votre planning a été validé!',
        html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>🎉 Excellente nouvelle! Votre planning a été validé par le Directeur Général!</p>
          <div style="background: #e3f2fd; padding: 15px; border-left: 4px solid #2196f3; margin: 20px 0;">
            <strong>Status:</strong> Planning validé ✓
          </div>
          <p>Votre planning est maintenant officiel et consultable par tous.</p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
    }),

    PLANNING_RETURNED: (user, comment) => ({
        subject: '📌 Votre planning doit être modifié',
        html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>📌 Votre planning a été retourné pour modifications.</p>
          <div style="background: #fff3e0; padding: 15px; border-left: 4px solid #ff9800; margin: 20px 0;">
            <strong>Commentaire du Directeur Général:</strong><br>
            ${comment}
          </div>
          <p>Veuillez corriger votre planning et le resoumetre dès que possible.</p>
          <p>
            <a href="${process.env.FRONTEND_URL}/planning" style="display: inline-block; background: #1F5C8B; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
              Modifier mon planning
            </a>
          </p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
    }),

    MEETING_CONVOCATION: (participant, meeting, room) => ({
        subject: `📅 Convocation : ${meeting.title}`,
        html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${participant.name},</p>
          <p>📅 Vous êtes convoqué à une réunion:</p>
          <div style="background: #f5f5f5; padding: 20px; border-left: 4px solid #1F5C8B; margin: 20px 0;">
            <h3 style="margin: 0 0 10px 0;">${meeting.title}</h3>
            <p><strong>📍 Lieu:</strong> ${room?.name || 'À définir'}</p>
            <p><strong>🕐 Date & Heure:</strong> ${new Date(meeting.startTime).toLocaleDateString('fr-FR')} à ${new Date(meeting.startTime).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</p>
            <p><strong>⏱ Durée:</strong> ${Math.round((new Date(meeting.endTime) - new Date(meeting.startTime)) / 60000)} minutes</p>
            <p><strong>📝 Ordre du jour:</strong> ${meeting.agenda}</p>
          </div>
          <p>
            <a href="${process.env.FRONTEND_URL}/meetings" style="display: inline-block; background: #1F5C8B; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
              Répondre à la convocation
            </a>
          </p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
    }),

    MEETING_SCHEDULE_UPDATED: (participant, meeting, room) => ({
        subject: `📅 Modification : ${meeting.title} – nouvel horaire`,
        html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${participant.name},</p>
          <p>📅 L'horaire ou le lieu de la réunion suivante a été modifié :</p>
          <div style="background: #fff8e1; padding: 20px; border-left: 4px solid #ff9800; margin: 20px 0;">
            <h3 style="margin: 0 0 10px 0;">${meeting.title}</h3>
            <p><strong>📍 Lieu:</strong> ${room?.name || 'À définir'}</p>
            <p><strong>🕐 Date & Heure:</strong> ${new Date(meeting.startTime).toLocaleDateString('fr-FR')} à ${new Date(meeting.startTime).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</p>
            <p><strong>⏱ Fin:</strong> ${new Date(meeting.endTime).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</p>
            <p><strong>⏱ Durée:</strong> ${Math.round((new Date(meeting.endTime) - new Date(meeting.startTime)) / 60000)} minutes</p>
            <p><strong>📝 Ordre du jour:</strong> ${meeting.agenda || '—'}</p>
          </div>
          <p>Veuillez prendre note des nouveaux horaires.</p>
          <p>
            <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/meetings" style="display: inline-block; background: #1F5C8B; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
              Voir la réunion
            </a>
          </p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
    }),

    MEETING_REMINDER: (participant, meeting, room) => ({
        subject: `🔔 Rappel: Réunion demain - ${meeting.title}`,
        html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${participant.name},</p>
          <p>🔔 Rappel: Une réunion est prévue demain</p>
          <div style="background: #fff8e1; padding: 20px; border-left: 4px solid #fbc02d; margin: 20px 0;">
            <h3 style="margin: 0 0 10px 0;">${meeting.title}</h3>
            <p><strong>🕐 Demain à:</strong> ${new Date(meeting.startTime).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</p>
            <p><strong>📍 Salle:</strong> ${room?.name || 'À définir'}</p>
          </div>
          <p>Assurez-vous d'être disponible à l'heure.</p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
  }),

  PASSWORD_RESET: (user, resetUrl) => ({
    subject: '🔑 Réinitialisation de votre mot de passe',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>Vous avez demandé la réinitialisation de votre mot de passe.</p>
          <div style="background: #fff3e0; padding: 15px; border-left: 4px solid #ff9800; margin: 20px 0;">
            <strong>⚠️ Ce lien est valable 1 heure.</strong>
          </div>
          <p>
            <a href="${resetUrl}" style="display: inline-block; background: #1F5C8B; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;">
              Réinitialiser mon mot de passe
            </a>
          </p>
          <p style="font-size: 12px; color: #999; margin-top: 16px;">
            Si vous n'êtes pas à l'origine de cette demande, ignorez cet email.
          </p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
  }),

  ACCOUNT_CREATED: (user, password) => ({
    subject: '👋 Bienvenue sur Gestion Planning - Vos identifiants',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>Votre compte a été créé sur <strong>Gestion Planning</strong>.</p>
          <div style="background: #e8f5e9; padding: 20px; border-left: 4px solid #4caf50; margin: 20px 0;">
            <p style="margin: 0 0 8px 0;"><strong>📧 Email :</strong> ${user.email}</p>
            <p style="margin: 0 0 8px 0;"><strong>🔑 Mot de passe :</strong> ${password}</p>
            <p style="margin: 0;"><strong>👤 Rôle :</strong> ${user.role}</p>
          </div>
          <p style="color: #e53935;"><strong>⚠️ Changez votre mot de passe dès la première connexion.</strong></p>
          <p>
            <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/login" style="display: inline-block; background: #1F5C8B; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;">
              Se connecter
            </a>
          </p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
  }),

  ROLE_CHANGED: (user, newRoleLabel, previousRoleLabel) => ({
    subject: '👤 Votre rôle a été modifié - Gestion Planning',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>Votre rôle sur l'application <strong>Gestion Planning</strong> a été modifié par un administrateur.</p>
          <div style="background: #e3f2fd; padding: 15px; border-left: 4px solid #2196f3; margin: 20px 0;">
            <p style="margin: 0 0 6px 0;"><strong>Ancien rôle :</strong> ${previousRoleLabel || '—'}</p>
            <p style="margin: 0;"><strong>Nouveau rôle :</strong> ${newRoleLabel || user.role}</p>
          </div>
          <p>Vos droits d'accès ont été mis à jour en conséquence. Reconnectez-vous si nécessaire pour voir les changements.</p>
          <p>
            <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/login" style="display: inline-block; background: #1F5C8B; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;">
              Accéder à l'application
            </a>
          </p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
  }),

  ACCOUNT_ACTIVATION: (user, activationUrl, password) => ({
    subject: '✅ Activez votre compte Gestion Planning',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>Votre compte a été créé sur <strong>Gestion Planning</strong>. Pour pouvoir vous connecter, vous devez d'abord l'activer en cliquant sur le lien ci-dessous.</p>
          <div style="text-align: center; margin: 28px 0;">
            <a href="${activationUrl}" style="display: inline-block; background: #4caf50; color: white; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: bold; font-size: 16px;">
              Activer mon compte
            </a>
          </div>
          <p style="font-size: 12px; color: #666;">Si le bouton ne fonctionne pas, copiez ce lien dans votre navigateur :</p>
          <p style="font-size: 12px; word-break: break-all; color: #1F5C8B;">${activationUrl}</p>
          <div style="background: #f5f5f5; padding: 16px; border-left: 4px solid #1F5C8B; margin: 20px 0;">
            <p style="margin: 0 0 6px 0;"><strong>Vos identifiants après activation :</strong></p>
            <p style="margin: 0 0 4px 0;"><strong>📧 Email :</strong> ${user.email}</p>
            <p style="margin: 0 0 4px 0;"><strong>🔑 Mot de passe :</strong> ${password}</p>
          </div>
          <p style="color: #e53935; font-size: 13px;"><strong>⚠️ Ce lien expire sous 7 jours. Changez votre mot de passe après votre première connexion.</strong></p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
  }),

  MISSION_CREATED: (user, mission, createdByName) => {
    const startStr = new Date(mission.startTime).toLocaleString('fr-FR', { dateStyle: 'full', timeStyle: 'short' });
    const endStr = new Date(mission.endTime).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    const url = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/missions/${mission.id}`;
    return {
      subject: `📍 Nouvelle mission : ${mission.title}`,
      html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>Une nouvelle mission vous a été assignée par <strong>${createdByName}</strong>.</p>
          <div style="background: #e3f2fd; padding: 20px; border-left: 4px solid #1F5C8B; margin: 20px 0;">
            <p style="margin: 0 0 8px 0;"><strong>📍 Mission :</strong> ${mission.title}</p>
            <p style="margin: 0 0 8px 0;"><strong>📍 Lieu :</strong> ${mission.location}</p>
            <p style="margin: 0 0 8px 0;"><strong>🕐 Début :</strong> ${startStr}</p>
            <p style="margin: 0 0 8px 0;"><strong>🕐 Fin :</strong> ${endStr}</p>
            ${mission.description ? `<p style="margin: 8px 0 0 0;"><strong>Description :</strong><br/>${mission.description}</p>` : ''}
          </div>
          <p>
            <a href="${url}" style="display: inline-block; background: #1F5C8B; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;">
              Voir la mission
            </a>
          </p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
    };
  },

  ACCOUNT_ACTIVATED: (user) => ({
    subject: '✅ Votre compte a été réactivé - Gestion Planning',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>Votre compte a été <strong>réactivé</strong> par un administrateur. Vous pouvez à nouveau vous connecter à l'application.</p>
          <p>
            <a href="${process.env.FRONTEND_URL || 'http://localhost:5173'}/login" style="display: inline-block; background: #4caf50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;">
              Se connecter
            </a>
          </p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
  }),

  ACCOUNT_DEACTIVATED: (user) => ({
    subject: '⚠️ Votre compte a été désactivé - Gestion Planning',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>Votre compte sur <strong>Gestion Planning</strong> a été <strong>désactivé</strong> par un administrateur. Vous ne pouvez plus vous connecter pour le moment.</p>
          <p>Pour toute question, contactez votre administrateur.</p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
  }),

  MISSION_UPDATED: (user, mission, createdByName) => {
    const startStr = new Date(mission.startTime).toLocaleString('fr-FR', { dateStyle: 'full', timeStyle: 'short' });
    const endStr = new Date(mission.endTime).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    const url = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/missions/${mission.id}`;
    return {
      subject: `📍 Mission modifiée : ${mission.title}`,
      html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>Une mission à laquelle vous êtes assigné(e) a été modifiée par <strong>${createdByName}</strong>.</p>
          <div style="background: #fff3e0; padding: 20px; border-left: 4px solid #ff9800; margin: 20px 0;">
            <p style="margin: 0 0 8px 0;"><strong>📍 Mission :</strong> ${mission.title}</p>
            <p style="margin: 0 0 8px 0;"><strong>📍 Lieu :</strong> ${mission.location}</p>
            <p style="margin: 0 0 8px 0;"><strong>🕐 Début :</strong> ${startStr}</p>
            <p style="margin: 0 0 8px 0;"><strong>🕐 Fin :</strong> ${endStr}</p>
            ${mission.description ? `<p style="margin: 8px 0 0 0;"><strong>Description :</strong><br/>${mission.description}</p>` : ''}
          </div>
          <p>
            <a href="${url}" style="display: inline-block; background: #1F5C8B; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;">
              Voir la mission
            </a>
          </p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
    };
  },

  MISSION_CANCELLED: (user, mission, createdByName) => {
    return {
      subject: `❌ Mission annulée : ${mission.title}`,
      html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>La mission <strong>« ${mission.title } »</strong> (${mission.location}) à laquelle vous étiez assigné(e) a été <strong>annulée</strong> par ${createdByName}.</p>
          <p>Vous n'avez plus à vous rendre sur cette mission.</p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
    };
  },

  // Rappel réunion J-1 — CDC §3.3.2
  MEETING_REMINDER: (user, meeting) => {
    const dateStr = new Date(meeting.startTime).toLocaleString('fr-FR', { dateStyle: 'full', timeStyle: 'short' });
    const endStr = new Date(meeting.endTime).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    const url = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/meetings/${meeting.id}`;
    return {
      subject: `⏰ Rappel : Réunion demain — ${meeting.title}`,
      html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #1F5C8B 0%, #2a7cb8 100%); color: white; padding: 20px; text-align: center;">
          <h1>Gestion Planning</h1>
        </div>
        <div style="padding: 20px;">
          <p>Bonjour ${user.name},</p>
          <p>Rappel : vous êtes convié(e) à une réunion <strong>demain</strong>.</p>
          <div style="background: #fff3e0; padding: 20px; border-left: 4px solid #ff9800; margin: 20px 0;">
            <p style="margin: 0 0 8px 0;"><strong>📋 Objet :</strong> ${meeting.title}</p>
            <p style="margin: 0 0 8px 0;"><strong>🕐 Horaire :</strong> ${dateStr} – ${endStr}</p>
            ${meeting.room ? `<p style="margin: 0 0 8px 0;"><strong>📍 Salle :</strong> ${meeting.room.name}</p>` : ''}
            ${meeting.agenda ? `<p style="margin: 8px 0 0 0;"><strong>Ordre du jour :</strong><br/>${meeting.agenda}</p>` : ''}
          </div>
          <p>
            <a href="${url}" style="display: inline-block; background: #1F5C8B; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold;">
              Voir la réunion
            </a>
          </p>
        </div>
        <div style="border-top: 1px solid #ddd; padding: 20px; text-align: center; font-size: 12px; color: #666;">
          <p>© 2026 Gestion Planning - Tous droits réservés</p>
        </div>
      </div>
    `,
    };
  },
};

// Classe de gestion des notifications
class NotificationService {
    constructor() {
        this.retryAttempts = 3;
        // Délais CDC §3.8.2 : 1 min, 5 min, 15 min
        this.retryDelays = [60_000, 300_000, 900_000];
    }

    /**
     * Envoyer un email avec retry logic (CDC §3.8.2)
     * 3 essais, délais : 1 min, 5 min, 15 min
     */
    async sendEmailWithRetry(to, templateKey, params = []) {
        return this.sendEmail(to, templateKey, params, 1);
    }

    /**
     * Envoyer un email avec retry logic
     */
    async sendEmail(to, templateKey, params = [], attempt = 1) {
        try {
            const template = emailTemplates[templateKey];
            if (!template) {
                logger.warn('EMAIL', `Template ${templateKey} non trouvé`);
                return { success: false, error: 'Template not found' };
            }

            const mailOptions = template(...params);
            const info = await transporter.sendMail({
                from: process.env.SMTP_FROM || 'noreply@gestionplanning.local',
                to,
                subject: mailOptions.subject,
                html: mailOptions.html,
            });

            logger.success(
                'EMAIL_SENT',
                `Email envoyé à ${to} - Template: ${templateKey}`, { to, templateKey, messageId: info.messageId }
            );

            return { success: true, messageId: info.messageId };
        } catch (error) {
            logger.error(
                'EMAIL_FAILED',
                `Échec d'envoi email (tentative ${attempt}/${this.retryAttempts})`, {
                    to,
                    templateKey,
                    error: error.message,
                }
            );

            if (attempt < this.retryAttempts) {
                // Retry avec délais CDC §3.8.2 : 1 min, 5 min, 15 min
                const delay = this.retryDelays[attempt - 1] ?? 60_000;
                await new Promise((resolve) => setTimeout(resolve, delay));
                return this.sendEmail(to, templateKey, params, attempt + 1);
            }

            return { success: false, error: error.message };
        }
    }

    /**
     * Envoyer un email avec contenu HTML libre (ex: rapport hebdomadaire)
     */
    async sendRawEmail(to, subject, html) {
        try {
            const info = await transporter.sendMail({
                from: process.env.SMTP_FROM || 'noreply@gestionplanning.local',
                to,
                subject,
                html,
            });
            logger.success('EMAIL_SENT', `Rapport envoyé à ${to}`, { to, messageId: info.messageId });
            return { success: true, messageId: info.messageId };
        } catch (error) {
            logger.error('EMAIL_FAILED', `Échec envoi rapport à ${to}`, { to, error: error.message });
            return { success: false, error: error.message };
        }
    }

    /**
     * Créer une notification in-app
     */
    async createNotification(prisma, userId, type, title, body, link = null) {
        try {
            const notification = await prisma.notification.create({
                data: {
                    userId,
                    type,
                    title,
                    body,
                    link,
                    isRead: false,
                },
            });

            logger.success(
                'NOTIFICATION_CREATED',
                `Notification créée pour l'utilisateur ${userId}`, { notificationId: notification.id, type, userId }
            );

            return notification;
        } catch (error) {
            logger.error('NOTIFICATION_ERROR', 'Erreur lors de la création de notification', {
                userId,
                type,
                error: error.message,
            });
            return null;
        }
    }

    /**
     * Envoyer une notification complète (email + in-app)
     */
    async sendFullNotification(
        prisma,
        userId,
        email,
        notificationType,
        emailTemplate,
        templateParams,
        inAppTitle,
        inAppBody,
        inAppLink
    ) {
        try {
            // Envoyer l'email
            const emailResult = await this.sendEmail(email, emailTemplate, templateParams);

            // Créer la notification in-app
            const notification = await this.createNotification(
                prisma,
                userId,
                notificationType,
                inAppTitle,
                inAppBody,
                inAppLink
            );

            logger.success('FULL_NOTIFICATION_SENT', `Notification complète envoyée à ${email}`, {
                userId,
                emailSent: emailResult.success,
                inAppCreated: notification !== null,
            });

            return {
                success: emailResult.success && notification !== null,
                email: emailResult,
                inApp: notification,
            };
        } catch (error) {
            logger.error('FULL_NOTIFICATION_ERROR', 'Erreur lors de l\'envoi de notification complète', {
                userId,
                error: error.message,
            });
            return { success: false, error: error.message };
        }
    }

    /**
     * Envoyer une notification à plusieurs utilisateurs
     */
    async sendBulkNotification(prisma, userIds, notificationType, title, body, link = null) {
        const results = [];

        for (const userId of userIds) {
            try {
                const notification = await this.createNotification(
                    prisma,
                    userId,
                    notificationType,
                    title,
                    body,
                    link
                );
                results.push({ userId, success: notification !== null });
            } catch (error) {
                results.push({ userId, success: false, error: error.message });
            }
        }

        logger.info('BULK_NOTIFICATION_SENT', `${results.filter((r) => r.success).length}/${results.length} notifications envoyées`, {
            total: results.length,
            succeeded: results.filter((r) => r.success).length,
        });

        return results;
    }

    /**
     * Marquer une notification comme lue
     */
    async markAsRead(prisma, notificationId) {
        try {
            const notification = await prisma.notification.update({
                where: { id: notificationId },
                data: { isRead: true },
            });

            logger.debug('NOTIFICATION_READ', `Notification ${notificationId} marquée comme lue`);
            return notification;
        } catch (error) {
            logger.error('NOTIFICATION_READ_ERROR', 'Erreur lors de la lecture de notification', {
                notificationId,
                error: error.message,
            });
            return null;
        }
    }

    /**
     * Récupérer les notifications de l'utilisateur avec pagination (pour GET /api/notifications)
     */
    async getNotifications(prisma, userId, skip = 0, limit = 20) {
        try {
            const [notifications, total, unread] = await Promise.all([
                prisma.notification.findMany({
                    where: { userId },
                    orderBy: { createdAt: 'desc' },
                    skip,
                    take: limit,
                }),
                prisma.notification.count({ where: { userId } }),
                prisma.notification.count({ where: { userId, isRead: false } }),
            ]);

            return { notifications, total, unread };
        } catch (error) {
            logger.error('GET_NOTIFICATIONS_ERROR', 'Erreur récupération notifications', {
                userId,
                error: error.message,
            });
            throw error;
        }
    }

    /**
     * Compter les notifications non lues (pour GET /api/notifications/unread/count)
     */
    async getUnreadCount(prisma, userId) {
        try {
            return await prisma.notification.count({
                where: { userId, isRead: false },
            });
        } catch (error) {
            logger.error('UNREAD_COUNT_ERROR', error.message, { userId });
            throw error;
        }
    }

    /**
     * Marquer toutes les notifications comme lues
     */
    async markAllAsRead(prisma, userId) {
        try {
            await prisma.notification.updateMany({
                where: { userId },
                data: { isRead: true },
            });
            return true;
        } catch (error) {
            logger.error('MARK_ALL_AS_READ_ERROR', error.message, { userId });
            throw error;
        }
    }

    /**
     * Obtenir les notifications non lues d'un utilisateur
     */
    async getUnreadNotifications(prisma, userId) {
        try {
            const notifications = await prisma.notification.findMany({
                where: {
                    userId,
                    isRead: false,
                },
                orderBy: { createdAt: 'desc' },
            });

            return notifications;
        } catch (error) {
            logger.error('UNREAD_NOTIFICATIONS_ERROR', 'Erreur lors de la récupération des notifications', {
                userId,
                error: error.message,
            });
            return [];
        }
    }

    /**
     * Supprimer les anciennes notifications (older than days)
     */
    async cleanupOldNotifications(prisma, days = 30) {
        try {
            const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

            const deleted = await prisma.notification.deleteMany({
                where: {
                    createdAt: { lt: cutoff },
                    isRead: true,
                },
            });

            logger.info('NOTIFICATIONS_CLEANUP', `${deleted.count} anciennes notifications supprimées`);
            return deleted;
        } catch (error) {
            logger.error('NOTIFICATIONS_CLEANUP_ERROR', 'Erreur lors du nettoyage des notifications', {
                error: error.message,
            });
            return null;
        }
    }
}

// Exporter l'instance singleton
const notificationService = new NotificationService();

module.exports = { notificationService, emailTemplates };